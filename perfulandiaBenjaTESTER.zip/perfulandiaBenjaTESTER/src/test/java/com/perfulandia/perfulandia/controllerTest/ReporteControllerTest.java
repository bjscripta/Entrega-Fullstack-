package com.perfulandia.perfulandia.controllerTest;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.perfulandia.perfulandia.Service.ReporteService;
import com.perfulandia.perfulandia.controller.ReporteController;
import com.perfulandia.perfulandia.model.Reporte;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import static org.mockito.ArgumentMatchers.any;

import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import java.util.List;

import static org.hamcrest.Matchers.*;
import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;

import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(ReporteController.class)
public class ReporteControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private ReporteService reporteService;

    @Autowired
    private ObjectMapper objectMapper;

    private Reporte reporte;

    @BeforeEach
    void setUp() {
        reporte = new Reporte();
        reporte.setIdReporte(1);
        reporte.setTituloReporte("Problema en sistema");
        reporte.setDescripcionReporte("Error al cargar los datos");
        reporte.setEstadoReporte("PENDIENTE");
    }

    @Test
    public void testListarTodos() throws Exception {
        when(reporteService.getReportes()).thenReturn(List.of(reporte));

        mockMvc.perform(get("/api/v1/reportes"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].tituloReporte", is("Problema en sistema")));
    }

    @Test
    public void testGuardarReporte() throws Exception {
        when(reporteService.saveReporte(any(Reporte.class))).thenReturn(reporte);

        mockMvc.perform(post("/api/v1/reportes")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(reporte)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.descripcionReporte", is("Error al cargar los datos")));
    }

    @Test
    public void eliminarReporte() throws Exception {
        int id = 1;

        when(reporteService.deleteReporte(id)).thenReturn("Reporte eliminado!");

        mockMvc.perform(delete("/api/v1/reportes/{idReporte}", id))
                .andExpect(status().isOk())
                .andExpect(content().string("Reporte eliminado!"));
}


    @Test
    public void testObtenerReportePorId() throws Exception {
        when(reporteService.getReporteById(1)).thenReturn(reporte);

        mockMvc.perform(get("/api/v1/reportes/1"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.estadoReporte", is("PENDIENTE")));
    }

    @Test
    public void testActualizarEstadoReporte() throws Exception {
        reporte.setEstadoReporte("RESUELTO");
        when(reporteService.actualizarEstadoReporte(1)).thenReturn(reporte);

        mockMvc.perform(put("/api/v1/reportes/resolverReporte/1"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.estadoReporte", is("RESUELTO")));
    }
}
