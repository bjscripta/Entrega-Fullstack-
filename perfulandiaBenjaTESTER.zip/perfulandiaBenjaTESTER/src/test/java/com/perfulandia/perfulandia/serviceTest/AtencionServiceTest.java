package com.perfulandia.perfulandia.serviceTest;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.*;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import com.perfulandia.perfulandia.model.Atencion;
import com.perfulandia.perfulandia.repository.AtencionRepositoryJPA;
import com.perfulandia.perfulandia.Service.AtencionService;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

public class AtencionServiceTest {

    @Mock
    private AtencionRepositoryJPA atencionRepository;

    @InjectMocks
    private AtencionService atencionService;

    private Atencion atencion;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);

        atencion = new Atencion();
        atencion.setIdAtencion(1);
        atencion.setTituloAtencion("No puedo iniciar sesión");
        atencion.setDescripcionAtencion("El usuario no puede iniciar sesión en la plataforma");
        atencion.setEstadoAtencion("Pendiente");
    }

    @Test
    public void testGetAtenciones() {
        when(atencionRepository.findAll()).thenReturn(Arrays.asList(atencion));

        List<Atencion> resultado = atencionService.getAtenciones();

        assertThat(resultado).isNotEmpty();
        assertThat(resultado.get(0).getTituloAtencion()).isEqualTo("No puedo iniciar sesión");
    }

    @Test
    public void testGetAtencionById_Success() {
        when(atencionRepository.findById(1)).thenReturn(Optional.of(atencion));

        Atencion resultado = atencionService.getAtencionById(1);

        assertThat(resultado).isNotNull();
        assertThat(resultado.getEstadoAtencion()).isEqualTo("Pendiente");
    }

    @Test
    public void testGetAtencionById_NotFound() {
        when(atencionRepository.findById(2)).thenReturn(Optional.empty());

        assertThrows(RuntimeException.class, () -> {
            atencionService.getAtencionById(2);
        });
    }

    @Test
    public void testSaveAtencion() {
        when(atencionRepository.save(atencion)).thenReturn(atencion);

        Atencion resultado = atencionService.saveAtencion(atencion);

        assertThat(resultado).isNotNull();
        assertThat(resultado.getTituloAtencion()).isEqualTo("No puedo iniciar sesión");
    }

    @Test
    public void testDeleteAtencion() {
        doNothing().when(atencionRepository).deleteById(1);

        String mensaje = atencionService.deleteAtencion(1);

        assertThat(mensaje).isEqualTo("Atencion elimnada!");
        verify(atencionRepository, times(1)).deleteById(1);
    }

    @Test
    public void testActualizarEstadoAtencion() {
        when(atencionRepository.findById(1)).thenReturn(Optional.of(atencion));
        when(atencionRepository.save(any(Atencion.class))).thenReturn(atencion);

        Atencion actualizado = atencionService.actualizarEstadoAtencion(1);

        assertThat(actualizado.getEstadoAtencion()).isEqualTo("RESUELTO");
    }
}
