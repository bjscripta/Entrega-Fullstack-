package com.perfulandia.perfulandia.serviceTest;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.*;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import com.perfulandia.perfulandia.Service.ReporteService;
import com.perfulandia.perfulandia.model.Reporte;
import com.perfulandia.perfulandia.repository.ReporteRepositoryJPA;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

public class ReporteServiceTest {

    @Mock
    private ReporteRepositoryJPA reporteRepository;

    @InjectMocks
    private ReporteService reporteService;

    private Reporte reporte;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);

        reporte = new Reporte();
        reporte.setIdReporte(1);
        reporte.setTituloReporte("Problema con el producto");
        reporte.setDescripcionReporte("El producto llegó dañado");
        reporte.setEstadoReporte("Pendiente");
    }

    @Test
    public void testGetReportes() {
        when(reporteRepository.findAll()).thenReturn(Arrays.asList(reporte));

        List<Reporte> resultado = reporteService.getReportes();

        assertThat(resultado).isNotEmpty();
        assertThat(resultado.get(0).getTituloReporte()).isEqualTo("Problema con el producto");
    }

    @Test
    public void testGetReporteById_Success() {
        when(reporteRepository.findById(1)).thenReturn(Optional.of(reporte));

        Reporte resultado = reporteService.getReporteById(1);

        assertThat(resultado).isNotNull();
        assertThat(resultado.getEstadoReporte()).isEqualTo("Pendiente");
    }

    @Test
    public void testGetReporteById_NotFound() {
        when(reporteRepository.findById(2)).thenReturn(Optional.empty());

        assertThrows(RuntimeException.class, () -> {
            reporteService.getReporteById(2);
        });
    }

    @Test
    public void testSaveReporte() {
        when(reporteRepository.save(reporte)).thenReturn(reporte);

        Reporte resultado = reporteService.saveReporte(reporte);

        assertThat(resultado).isNotNull();
        assertThat(resultado.getTituloReporte()).isEqualTo("Problema con el producto");
    }

    @Test
    public void testDeleteReporte() {
        doNothing().when(reporteRepository).deleteById(1);

        String mensaje = reporteService.deleteReporte(1);

        assertThat(mensaje).isEqualTo("Reporte eliminado!");
        verify(reporteRepository, times(1)).deleteById(1);
    }

    @Test
    public void testActualizarEstadoReporte() {
        when(reporteRepository.findById(1)).thenReturn(Optional.of(reporte));
        when(reporteRepository.save(any(Reporte.class))).thenReturn(reporte);

        Reporte actualizado = reporteService.actualizarEstadoReporte(1);

        assertThat(actualizado.getEstadoReporte()).isEqualTo("RESUELTO");
    }
}
