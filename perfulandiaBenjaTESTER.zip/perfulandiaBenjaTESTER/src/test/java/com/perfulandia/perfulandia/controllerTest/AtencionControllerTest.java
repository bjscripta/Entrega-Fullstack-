package com.perfulandia.perfulandia.controllerTest;

import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.web.servlet.MockMvc;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.perfulandia.perfulandia.controller.AtencionController;
import com.perfulandia.perfulandia.Service.AtencionService;
import com.perfulandia.perfulandia.model.Atencion;

@WebMvcTest(AtencionController.class)
public class AtencionControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private AtencionService atencionService;

    @Autowired
    private ObjectMapper objectMapper;

    private Atencion atencion;

    @BeforeEach
    void setUp() {
        atencion = new Atencion();
        atencion.setIdAtencion(1);
        atencion.setTituloAtencion("No puedo iniciar sesion");
        atencion.setDescripcionAtencion("Necesito ayuda para iniciar sesion....");
        atencion.setEstadoAtencion("En revision");
    }

    @Test //LISTAR ATENCION
    public void listarTodasAtenciones() throws Exception {
        when(atencionService.getAtenciones()).thenReturn(List.of(atencion)); 

        mockMvc.perform(get("/api/v1/atenciones"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].idAtencion").value(1))
                .andExpect(jsonPath("$[0].tituloAtencion").value("No puedo iniciar sesion"));
    }

    @Test //AGREGAR ATENCION
    public void guardarAtencion() throws Exception {
        when(atencionService.saveAtencion(atencion)).thenReturn(atencion);

        mockMvc.perform(post("/api/v1/atenciones")
                .contentType("application/json")
                .content(objectMapper.writeValueAsString(atencion)))
            .andExpect(status().isOk())
            .andExpect(jsonPath("$.idAtencion").value(atencion.getIdAtencion()))
            .andExpect(jsonPath("$.tituloAtencion").value(atencion.getTituloAtencion()));
    }

    @Test//ELIMINAR ATENCION
    public void eliminarAtencion() throws Exception {
        mockMvc.perform(delete("/api/v1/atenciones/1"))
            .andExpect(status().isOk());
    }

    @Test //ACTUALIZAR ESTADO DE SOLICITUD
    public void marcarAtencionComoResuelta() throws Exception {
    Atencion atencionResuelta = new Atencion();
    atencionResuelta.setIdAtencion(1);
    atencionResuelta.setTituloAtencion("No puedo iniciar sesion");
    atencionResuelta.setDescripcionAtencion("Necesito ayuda para iniciar sesion....");
    atencionResuelta.setEstadoAtencion("RESUELTO");

    when(atencionService.actualizarEstadoAtencion(1)).thenReturn(atencionResuelta);

    mockMvc.perform(put("/api/v1/atenciones/resolverAtencion/1"))
        .andExpect(status().isOk())
        .andExpect(jsonPath("$.estadoAtencion").value("RESUELTO"));
    }

    @Test//BUSCAR ATENCION POR ID 
    public void obtenerAtencionPorId() throws Exception {
        when(atencionService.getAtencionById(1)).thenReturn(atencion);

        mockMvc.perform(get("/api/v1/atenciones/1"))
            .andExpect(status().isOk())
            .andExpect(jsonPath("$.idAtencion").value(1))
            .andExpect(jsonPath("$.estadoAtencion").value("En revision"));
    }

}
