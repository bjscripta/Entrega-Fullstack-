package com.perfulandia.perfulandia.modelTest;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

import com.perfulandia.perfulandia.model.Reporte;

public class ReporteModelTest {

    @Test
    public void testCreacionYAccesoCampos() {
        Reporte reporte = new Reporte();

        reporte.setIdReporte(1);
        reporte.setTituloReporte("Problema con el sistema");
        reporte.setDescripcionReporte("El sistema presenta errores intermitentes.");
        reporte.setEstadoReporte("Pendiente");

        assertEquals(1, reporte.getIdReporte());
        assertEquals("Problema con el sistema", reporte.getTituloReporte());
        assertEquals("El sistema presenta errores intermitentes.", reporte.getDescripcionReporte());
        assertEquals("Pendiente", reporte.getEstadoReporte());
    }
}
