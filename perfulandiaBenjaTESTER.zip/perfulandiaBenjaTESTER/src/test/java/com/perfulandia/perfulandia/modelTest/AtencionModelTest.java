package com.perfulandia.perfulandia.modelTest;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

import com.perfulandia.perfulandia.model.Atencion;

public class AtencionModelTest {

    @Test
    public void testCreacionYAccesoCampos() {
        Atencion atencion = new Atencion();

        atencion.setIdAtencion(1);
        atencion.setTituloAtencion("No puedo iniciar sesión");
        atencion.setDescripcionAtencion("El usuario no puede iniciar sesión");
        atencion.setEstadoAtencion("Pendiente");

        assertEquals(1, atencion.getIdAtencion());
        assertEquals("No puedo iniciar sesión", atencion.getTituloAtencion());
        assertEquals("El usuario no puede iniciar sesión", atencion.getDescripcionAtencion());
        assertEquals("Pendiente", atencion.getEstadoAtencion());
    }

}
