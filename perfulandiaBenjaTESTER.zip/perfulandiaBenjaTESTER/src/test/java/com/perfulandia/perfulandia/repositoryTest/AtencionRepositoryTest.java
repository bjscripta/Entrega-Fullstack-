package com.perfulandia.perfulandia.repositoryTest;

import static org.assertj.core.api.Assertions.assertThat;

import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;

import com.perfulandia.perfulandia.model.Atencion;
import com.perfulandia.perfulandia.repository.AtencionRepositoryJPA;

@DataJpaTest
public class AtencionRepositoryTest {

    @Autowired
    private AtencionRepositoryJPA atencionRepository;

    @Test
    public void SimulacionDeUser() {
        Atencion atencion = new Atencion();
        atencion.setIdAtencion(1);
        atencion.setTituloAtencion("problema de inicio de sesión");
        atencion.setDescripcionAtencion("El usuario no puede iniciar sesión.");
        atencion.setEstadoAtencion("Pendiente");

        atencionRepository.save(atencion); //INSERTAR

        Optional<Atencion> resultado = atencionRepository.findById(1); //BUSCA POR ID

        assertThat(resultado).isPresent(); //VERIFICACION
        assertThat(resultado.get().getTituloAtencion()).isEqualTo("problema de inicio de sesión"); //CAMBIA EL ESTADO

        atencionRepository.deleteById(1); //BORRAR POR ID 
    }
}
