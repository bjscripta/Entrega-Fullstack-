package com.venta.venta.service;

import com.venta.venta.model.DetalleVenta;
import com.venta.venta.model.Inventario;
import com.venta.venta.model.Producto;
import com.venta.venta.model.Usuario;
import com.venta.venta.model.Venta;
import com.venta.venta.repository.DetalleVentaRepository;
import com.venta.venta.repository.InventarioRepository;
import com.venta.venta.repository.VentaRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

public class VentaServiceTest {

    @Mock
    private VentaRepository ventaRepository;
    @Mock
    private DetalleVentaRepository detalleVentaRepository;
    @Mock
    private InventarioRepository inventarioRepository;

    @InjectMocks
    private VentaService ventaService;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void registrarVenta_Success() {
        // Arrange
        Usuario usuario = new Usuario(1L, "Test User");
        Producto producto1 = new Producto(101L, "Product A", 10.0);
        Producto producto2 = new Producto(102L, "Product B", 20.0);

        Inventario inventario1 = new Inventario(1L, producto1, 100);
        Inventario inventario2 = new Inventario(2L, producto2, 50);

        Venta venta = new Venta(null, "Test Venta", LocalDate.now(), usuario, new ArrayList<>());

        DetalleVenta detalle1 = new DetalleVenta(null, producto1, 2, null);
        DetalleVenta detalle2 = new DetalleVenta(null, producto2, 1, null);
        List<DetalleVenta> detalles = Arrays.asList(detalle1, detalle2);

        when(ventaRepository.save(any(Venta.class))).thenReturn(venta);
        when(inventarioRepository.findByProducto_IdProducto(producto1.getIdProducto())).thenReturn(Optional.of(inventario1));
        when(inventarioRepository.findByProducto_IdProducto(producto2.getIdProducto())).thenReturn(Optional.of(inventario2));
        when(inventarioRepository.save(any(Inventario.class))).thenAnswer(invocation -> invocation.getArgument(0));
        when(detalleVentaRepository.saveAll(anyList())).thenReturn(detalles);

        // Act
        ventaService.registrarVenta(venta, detalles);

        // Assert
        verify(ventaRepository, times(1)).save(venta);
        verify(inventarioRepository, times(1)).findByProducto_IdProducto(producto1.getIdProducto());
        verify(inventarioRepository, times(1)).findByProducto_IdProducto(producto2.getIdProducto());
        verify(inventarioRepository, times(2)).save(any(Inventario.class)); // For each inventory update
        verify(detalleVentaRepository, times(1)).saveAll(detalles);

        assertEquals(98, inventario1.getStock()); // 100 - 2
        assertEquals(49, inventario2.getStock()); // 50 - 1
        assertNotNull(detalle1.getVenta());
        assertNotNull(detalle2.getVenta());
    }

    @Test
    void registrarVenta_InventarioNotFound() {
        // Arrange
        Usuario usuario = new Usuario(1L, "Test User");
        Producto producto1 = new Producto(101L, "Product A", 10.0);

        Venta venta = new Venta(null, "Test Venta", LocalDate.now(), usuario, new ArrayList<>());
        DetalleVenta detalle1 = new DetalleVenta(null, producto1, 2, null);
        List<DetalleVenta> detalles = Arrays.asList(detalle1);

        when(ventaRepository.save(any(Venta.class))).thenReturn(venta);
        when(inventarioRepository.findByProducto_IdProducto(producto1.getIdProducto())).thenReturn(Optional.empty());

        // Act & Assert
        RuntimeException exception = assertThrows(RuntimeException.class, () ->
                ventaService.registrarVenta(venta, detalles));

        assertEquals("Inventario no encontrado para el producto", exception.getMessage());
        verify(ventaRepository, times(1)).save(venta);
        verify(inventarioRepository, times(1)).findByProducto_IdProducto(producto1.getIdProducto());
        verify(inventarioRepository, times(0)).save(any(Inventario.class));
        verify(detalleVentaRepository, times(0)).saveAll(anyList());
    }

    @Test
    void registrarVenta_InsufficientStock() {
        // Arrange
        Usuario usuario = new Usuario(1L, "Test User");
        Producto producto1 = new Producto(101L, "Product A", 10.0);

        Inventario inventario1 = new Inventario(1L, producto1, 1); // Only 1 in stock
        Venta venta = new Venta(null, "Test Venta", LocalDate.now(), usuario, new ArrayList<>());
        DetalleVenta detalle1 = new DetalleVenta(null, producto1, 2, null); // Trying to buy 2
        List<DetalleVenta> detalles = Arrays.asList(detalle1);

        when(ventaRepository.save(any(Venta.class))).thenReturn(venta);
        when(inventarioRepository.findByProducto_IdProducto(producto1.getIdProducto())).thenReturn(Optional.of(inventario1));

        // Act & Assert
        RuntimeException exception = assertThrows(RuntimeException.class, () ->
                ventaService.registrarVenta(venta, detalles));

        assertEquals("Stock insuficiente para el producto: Product A", exception.getMessage());
        verify(ventaRepository, times(1)).save(venta);
        verify(inventarioRepository, times(1)).findByProducto_IdProducto(producto1.getIdProducto());
        verify(inventarioRepository, times(0)).save(any(Inventario.class));
        verify(detalleVentaRepository, times(0)).saveAll(anyList());
    }

    @Test
    void listar() {
        // Arrange
        Venta venta1 = new Venta(1L, "Sale 1", LocalDate.now(), new Usuario(1L, "User1"), new ArrayList<>());
        Venta venta2 = new Venta(2L, "Sale 2", LocalDate.now(), new Usuario(2L, "User2"), new ArrayList<>());
        when(ventaRepository.findAll()).thenReturn(Arrays.asList(venta1, venta2));

        // Act
        List<Venta> ventas = ventaService.listar();

        // Assert
        assertNotNull(ventas);
        assertEquals(2, ventas.size());
        verify(ventaRepository, times(1)).findAll();
    }

    @Test
    void obtenerPorId_Found() {
        // Arrange
        Long ventaId = 1L;
        Venta venta = new Venta(ventaId, "Sale 1", LocalDate.now(), new Usuario(1L, "User1"), new ArrayList<>());
        when(ventaRepository.findById(ventaId)).thenReturn(Optional.of(venta));

        // Act
        Venta foundVenta = ventaService.obtenerPorId(ventaId);

        // Assert
        assertNotNull(foundVenta);
        assertEquals(ventaId, foundVenta.getId());
        verify(ventaRepository, times(1)).findById(ventaId);
    }

    @Test
    void obtenerPorId_NotFound() {
        // Arrange
        Long ventaId = 1L;
        when(ventaRepository.findById(ventaId)).thenReturn(Optional.empty());

        // Act
        Venta foundVenta = ventaService.obtenerPorId(ventaId);

        // Assert
        assertNull(foundVenta);
        verify(ventaRepository, times(1)).findById(ventaId);
    }
}