package com.venta.venta.model;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class ProductoTest {

    @Test
    void testNoArgsConstructor() {
        Producto producto = new Producto();
        assertNotNull(producto);
    }

    @Test
    void testAllArgsConstructor() {
        Producto producto = new Producto(1L, "Laptop", 1200.00);
        assertEquals(1L, producto.getIdProducto());
        assertEquals("Laptop", producto.getNombre());
        assertEquals(1200.00, producto.getPrecio());
    }

    @Test
    void testGettersAndSetters() {
        Producto producto = new Producto();
        producto.setIdProducto(2L);
        producto.setNombre("Mouse");
        producto.setPrecio(25.50);

        assertEquals(2L, producto.getIdProducto());
        assertEquals("Mouse", producto.getNombre());
        assertEquals(25.50, producto.getPrecio());
    }

    @Test
    void testEqualsAndHashCode() {
        Producto producto1 = new Producto(1L, "Teclado", 75.00);
        Producto producto2 = new Producto(1L, "Teclado", 75.00);
        Producto producto3 = new Producto(2L, "Monitor", 300.00);

        assertEquals(producto1, producto2);
        assertNotEquals(producto1, producto3);
        assertEquals(producto1.hashCode(), producto2.hashCode());
        assertNotEquals(producto1.hashCode(), producto3.hashCode());
    }

    @Test
    void testToString() {
        Producto producto = new Producto(1L, "Webcam", 50.00);
        String expectedToString = "Producto(idProducto=1, nombre=Webcam, precio=50.0)";
        assertEquals(expectedToString, producto.toString());
    }
}