package com.venta.venta.model;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class UsuarioTest {

    @Test
    void testNoArgsConstructor() {
        Usuario usuario = new Usuario();
        assertNotNull(usuario);
    }

    @Test
    void testAllArgsConstructor() {
        Usuario usuario = new Usuario(1L, "Juan Perez");
        assertEquals(1L, usuario.getId());
        assertEquals("Juan Perez", usuario.getNombre());
    }

    @Test
    void testPartialConstructor() {
        Usuario usuario = new Usuario("Maria Lopez");
        assertNull(usuario.getId());
        assertEquals("Maria Lopez", usuario.getNombre());
    }

    @Test
    void testGettersAndSetters() {
        Usuario usuario = new Usuario();
        usuario.setId(2L);
        usuario.setNombre("Carlos Garcia");

        assertEquals(2L, usuario.getId());
        assertEquals("Carlos Garcia", usuario.getNombre());
    }

    @Test
    void testEqualsAndHashCode() {
        Usuario usuario1 = new Usuario(1L, "Ana Torres");
        Usuario usuario2 = new Usuario(1L, "Ana Torres");
        Usuario usuario3 = new Usuario(2L, "Pedro Soto");

        assertEquals(usuario1, usuario2);
        assertNotEquals(usuario1, usuario3);
        assertEquals(usuario1.hashCode(), usuario2.hashCode());
        assertNotEquals(usuario1.hashCode(), usuario3.hashCode());
    }

    @Test
    void testToString() {
        Usuario usuario = new Usuario(1L, "Elena Ruiz");
        String expectedToString = "Usuario(id=1, nombre=Elena Ruiz)";
        assertEquals(expectedToString, usuario.toString());
    }
}