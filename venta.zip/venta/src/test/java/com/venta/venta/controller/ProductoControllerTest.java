package com.venta.venta.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.venta.venta.dto.ProductoRequest;
import com.venta.venta.model.Producto;
import com.venta.venta.service.ProductoService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import java.util.Arrays;
import java.util.Optional;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(ProductoController.class)
public class ProductoControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private ProductoService productoService;

    @Autowired
    private ObjectMapper objectMapper;

    private Producto testProducto;
    private ProductoRequest testProductoRequest;

    @BeforeEach
    void setUp() {
        testProducto = new Producto(1L, "Laptop", 1200.00);
        testProductoRequest = new ProductoRequest();
        testProductoRequest.setNombre("Laptop");
        testProductoRequest.setPrecio(1200.00);
    }

    @Test
    void agregarProducto_Success() throws Exception {
        when(productoService.guardarProducto(any(Producto.class))).thenReturn(testProducto);

        mockMvc.perform(post("/api/v1/productos")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(testProductoRequest)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.idProducto").value(testProducto.getIdProducto()))
                .andExpect(jsonPath("$.nombre").value(testProducto.getNombre()))
                .andExpect(jsonPath("$.precio").value(testProducto.getPrecio()));

        verify(productoService, times(1)).guardarProducto(any(Producto.class));
    }

    @Test
    void listarProductos_Success() throws Exception {
        when(productoService.listarProductos()).thenReturn(Arrays.asList(testProducto));

        mockMvc.perform(get("/api/v1/productos")
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].idProducto").value(testProducto.getIdProducto()))
                .andExpect(jsonPath("$[0].nombre").value(testProducto.getNombre()));

        verify(productoService, times(1)).listarProductos();
    }

    @Test
    void obtenerProductoPorId_Found() throws Exception {
        when(productoService.obtenerPorId(testProducto.getIdProducto())).thenReturn(Optional.of(testProducto));

        mockMvc.perform(get("/api/v1/productos/{id}", testProducto.getIdProducto())
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.idProducto").value(testProducto.getIdProducto()))
                .andExpect(jsonPath("$.nombre").value(testProducto.getNombre()));

        verify(productoService, times(1)).obtenerPorId(testProducto.getIdProducto());
    }

    @Test
    void obtenerProductoPorId_NotFound() throws Exception {
        when(productoService.obtenerPorId(testProducto.getIdProducto())).thenReturn(Optional.empty());

        mockMvc.perform(get("/api/v1/productos/{id}", testProducto.getIdProducto())
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isNotFound())
                .andExpect(content().string("Producto no encontrado"));

        verify(productoService, times(1)).obtenerPorId(testProducto.getIdProducto());
    }

    @Test
    void actualizarProducto_Success() throws Exception {
        ProductoRequest updatedRequest = new ProductoRequest();
        updatedRequest.setNombre("Gaming Laptop");
        updatedRequest.setPrecio(1500.00);

        Producto updatedProducto = new Producto(testProducto.getIdProducto(), "Gaming Laptop", 1500.00);

        when(productoService.actualizarProducto(eq(testProducto.getIdProducto()), any(Producto.class)))
                .thenReturn(updatedProducto);

        mockMvc.perform(put("/api/v1/productos/{id}", testProducto.getIdProducto())
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(updatedRequest)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.idProducto").value(updatedProducto.getIdProducto()))
                .andExpect(jsonPath("$.nombre").value(updatedProducto.getNombre()))
                .andExpect(jsonPath("$.precio").value(updatedProducto.getPrecio()));

        verify(productoService, times(1)).actualizarProducto(eq(testProducto.getIdProducto()), any(Producto.class));
    }

    @Test
    void actualizarProducto_NotFound() throws Exception {
        ProductoRequest updatedRequest = new ProductoRequest();
        updatedRequest.setNombre("Gaming Laptop");
        updatedRequest.setPrecio(1500.00);

        when(productoService.actualizarProducto(eq(testProducto.getIdProducto()), any(Producto.class)))
                .thenThrow(new RuntimeException("Producto no encontrado"));

        mockMvc.perform(put("/api/v1/productos/{id}", testProducto.getIdProducto())
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(updatedRequest)))
                .andExpect(status().isNotFound())
                .andExpect(content().string("Producto no encontrado"));

        verify(productoService, times(1)).actualizarProducto(eq(testProducto.getIdProducto()), any(Producto.class));
    }

    @Test
    void eliminarProducto_Success() throws Exception {
        doNothing().when(productoService).eliminarProducto(testProducto.getIdProducto());

        mockMvc.perform(delete("/api/v1/productos/{id}", testProducto.getIdProducto())
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(content().string("Producto eliminado con éxito"));

        verify(productoService, times(1)).eliminarProducto(testProducto.getIdProducto());
    }

    @Test
    void eliminarProducto_NotFound() throws Exception {
        doThrow(new RuntimeException("Error deleting product")).when(productoService).eliminarProducto(testProducto.getIdProducto());

        mockMvc.perform(delete("/api/v1/productos/{id}", testProducto.getIdProducto())
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isNotFound())
                .andExpect(content().string("Producto no encontrado"));

        verify(productoService, times(1)).eliminarProducto(testProducto.getIdProducto());
    }
}