package com.venta.venta.service;

import com.venta.venta.model.Producto;
import com.venta.venta.repository.ProductoRepository;
// Importa la implementación si la tuvieras, en este caso es la misma interfaz
// import com.venta.venta.service.impl.ProductoServiceImpl; // <-- Si tuvieras una carpeta impl

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class ProductoServiceTest {

    @Mock // Simula el repositorio
    private ProductoRepository productoRepository;

    @InjectMocks // Inyecta los mocks en la instancia del servicio
    private ProductoService productoService; // Cambiado a la interfaz directamente, si tu @Service es ProductoService

    private Producto producto1;
    private Producto producto2;

    @BeforeEach
    void setUp() {
        producto1 = new Producto(1L, "Laptop", 1200.00);
        producto2 = new Producto(2L, "Mouse", 25.00);
    }

    @Test
    @DisplayName("Test para guardar un producto")
    void testGuardarProducto() {
        // Comportamiento esperado del mock del repositorio
        when(productoRepository.save(any(Producto.class))).thenReturn(producto1);

        // Llamada al método del servicio
        Producto savedProducto = productoService.guardarProducto(new Producto(null, "Laptop", 1200.00)); // Ajustado el nombre del método

        // Verificaciones
        assertThat(savedProducto).isNotNull();
        assertThat(savedProducto.getNombre()).isEqualTo("Laptop");
        verify(productoRepository, times(1)).save(any(Producto.class)); // Verifica que save fue llamado una vez
    }

    @Test
    @DisplayName("Test para obtener un producto por ID")
    void testObtenerProductoPorId() { // Ajustado el nombre del método
        // Comportamiento esperado del mock del repositorio
        when(productoRepository.findById(1L)).thenReturn(Optional.of(producto1));

        // Llamada al método del servicio
        Optional<Producto> foundProducto = productoService.obtenerPorId(1L); // Ajustado el nombre del método

        // Verificaciones
        assertThat(foundProducto).isPresent();
        assertThat(foundProducto.get().getNombre()).isEqualTo("Laptop");
        verify(productoRepository, times(1)).findById(1L);
    }

    @Test
    @DisplayName("Test para obtener un producto por ID no encontrado")
    void testObtenerProductoPorId_NotFound() { // Ajustado el nombre del método
        // Comportamiento esperado del mock del repositorio
        when(productoRepository.findById(99L)).thenReturn(Optional.empty());

        // Llamada al método del servicio
        Optional<Producto> foundProducto = productoService.obtenerPorId(99L); // Ajustado el nombre del método

        // Verificaciones
        assertThat(foundProducto).isNotPresent();
        verify(productoRepository, times(1)).findById(99L);
    }

    @Test
    @DisplayName("Test para obtener todos los productos")
    void testListarTodosLosProductos() { // Ajustado el nombre del método
        // Comportamiento esperado del mock del repositorio
        when(productoRepository.findAll()).thenReturn(Arrays.asList(producto1, producto2));

        // Llamada al método del servicio
        List<Producto> productos = productoService.listarProductos(); // Ajustado el nombre del método

        // Verificaciones
        assertThat(productos).isNotNull();
        assertThat(productos).hasSize(2);
        assertThat(productos).contains(producto1, producto2);
        verify(productoRepository, times(1)).findAll();
    }

    @Test
    @DisplayName("Test para actualizar un producto existente")
    void testActualizarProducto() { // Ajustado el nombre del método
        Producto updatedInfo = new Producto(null, "Laptop Pro", 1500.00);

        // Comportamiento esperado del mock del repositorio
        when(productoRepository.findById(1L)).thenReturn(Optional.of(producto1));
        when(productoRepository.save(any(Producto.class))).thenReturn(updatedInfo); // Simula el producto guardado

        // Llamada al método del servicio
        Producto result = productoService.actualizarProducto(1L, updatedInfo); // Ajustado el nombre del método

        // Verificaciones
        assertThat(result).isNotNull();
        assertThat(result.getNombre()).isEqualTo("Laptop Pro");
        assertThat(result.getPrecio()).isEqualTo(1500.00);
        verify(productoRepository, times(1)).findById(1L);
        verify(productoRepository, times(1)).save(any(Producto.class));
    }

    @Test
    @DisplayName("Test para actualizar un producto no existente")
    void testActualizarProducto_NotFound() { // Ajustado el nombre del método
        Producto updatedInfo = new Producto(null, "No Existe", 100.00);

        // Comportamiento esperado del mock del repositorio
        when(productoRepository.findById(99L)).thenReturn(Optional.empty());

        // Verificación de que se lanza una excepción
        assertThrows(RuntimeException.class, () -> productoService.actualizarProducto(99L, updatedInfo)); // Ajustado el nombre del método
        verify(productoRepository, times(1)).findById(99L);
        verify(productoRepository, never()).save(any(Producto.class)); // Asegura que save nunca fue llamado
    }

    @Test
    @DisplayName("Test para eliminar un producto")
    void testEliminarProducto() { // Ajustado el nombre del método
        // Comportamiento esperado del mock del repositorio
        // No hay un retorno, solo verificamos que el método fue llamado
        doNothing().when(productoRepository).deleteById(1L);

        // Llamada al método del servicio
        productoService.eliminarProducto(1L); // Ajustado el nombre del método

        // Verificaciones
        verify(productoRepository, times(1)).deleteById(1L);
    }
}