package com.venta.venta.model;

import org.junit.jupiter.api.Test;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class VentaTest {

    @Test
    void testNoArgsConstructor() {
        Venta venta = new Venta();
        assertNotNull(venta);
        assertNotNull(venta.getDetalles()); // Default initialized by Lombok's @Data with ArrayList
        assertTrue(venta.getDetalles().isEmpty());
    }

    @Test
    void testAllArgsConstructor() {
        Usuario usuario = new Usuario(1L, "Cliente A");
        List<DetalleVenta> detalles = new ArrayList<>();
        detalles.add(new DetalleVenta(1L, new Producto(1L, "Item 1", 10.0), 1, null));

        Venta venta = new Venta(1L, "Venta de prueba", LocalDate.of(2023, 1, 15), usuario, detalles);
        assertEquals(1L, venta.getId());
        assertEquals("Venta de prueba", venta.getDescripcion());
        assertEquals(LocalDate.of(2023, 1, 15), venta.getFechaVenta());
        assertEquals(usuario, venta.getUsuario());
        assertEquals(detalles, venta.getDetalles());
    }

    @Test
    void testGettersAndSetters() {
        Venta venta = new Venta();
        Usuario usuario = new Usuario(2L, "Cliente B");
        List<DetalleVenta> detalles = new ArrayList<>();
        detalles.add(new DetalleVenta(2L, new Producto(2L, "Item 2", 20.0), 2, null));

        venta.setId(2L);
        venta.setDescripcion("Otra venta");
        venta.setFechaVenta(LocalDate.of(2024, 5, 1));
        venta.setUsuario(usuario);
        venta.setDetalles(detalles);

        assertEquals(2L, venta.getId());
        assertEquals("Otra venta", venta.getDescripcion());
        assertEquals(LocalDate.of(2024, 5, 1), venta.getFechaVenta());
        assertEquals(usuario, venta.getUsuario());
        assertEquals(detalles, venta.getDetalles());
    }

    @Test
    void testEqualsAndHashCode() {
        Usuario usuario1 = new Usuario(1L, "User1");
        Usuario usuario2 = new Usuario(1L, "User1");

        Venta venta1 = new Venta(1L, "Desc A", LocalDate.now(), usuario1, Collections.emptyList());
        Venta venta2 = new Venta(1L, "Desc A", LocalDate.now(), usuario2, Collections.emptyList());
        Venta venta3 = new Venta(2L, "Desc B", LocalDate.now(), usuario1, Collections.emptyList());

        assertEquals(venta1, venta2);
        assertNotEquals(venta1, venta3);
        assertEquals(venta1.hashCode(), venta2.hashCode());
        assertNotEquals(venta1.hashCode(), venta3.hashCode());
    }

    @Test
    void testToString() {
        Usuario usuario = new Usuario(1L, "User C");
        Venta venta = new Venta(3L, "Test Venta", LocalDate.of(2023, 10, 20), usuario, Collections.emptyList());
        String expectedToString = "Venta(id=3, descripcion=Test Venta, fechaVenta=2023-10-20, usuario=Usuario(id=1, nombre=User C), detalles=[])";
        assertEquals(expectedToString, venta.toString());
    }
}   