package com.venta.venta.repository;

import com.venta.venta.model.DetalleVenta;
import com.venta.venta.model.Producto;
import com.venta.venta.model.Usuario;
import com.venta.venta.model.Venta;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase.Replace;

import java.time.LocalDate;
import java.util.ArrayList; // Mantenerlo por si lo usas en otros constructores o lógica
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;

@DataJpaTest
@AutoConfigureTestDatabase(replace = Replace.NONE) // Usa base de datos actual, no en memoria
class DetalleVentaRepositoryTest {

    @Autowired
    private DetalleVentaRepository detalleVentaRepository;

    @Autowired
    private ProductoRepository productoRepository;

    @Autowired
    private VentaRepository ventaRepository;

    @Autowired
    private UsuarioRepository usuarioRepository;

    private Producto testProducto;
    private Venta testVenta;
    private Usuario testUser; // Declarar testUser a nivel de clase para usarlo en otras pruebas si fuera necesario

    @BeforeEach
    void setUp() {
        // Limpieza de datos (opcional, pero buena práctica para tests)
        // Asegúrate de que el orden de borrado respete las dependencias de clave foránea
        detalleVentaRepository.deleteAllInBatch(); // deleteAllInBatch es más eficiente para tests
        ventaRepository.deleteAllInBatch();
        productoRepository.deleteAllInBatch();
        usuarioRepository.deleteAllInBatch();


        // 1. Crear un usuario de prueba
        testUser = usuarioRepository.save(new Usuario("Detail Test User"));

        // 2. Crear un producto de prueba
        testProducto = productoRepository.save(new Producto(null, "Test Product for Detail", 50.00));

        // 3. Crear una Venta de prueba
        testVenta = new Venta();
        testVenta.setDescripcion("Test Sale for Detail");
        testVenta.setFechaVenta(LocalDate.now());
        testVenta.setUsuario(testUser);

        // MODIFICACIÓN CLAVE: Crear un DetalleVenta y asociarlo a la Venta ANTES de guardar la Venta
        DetalleVenta initialDetalle = new DetalleVenta();
        initialDetalle.setProducto(testProducto);
        initialDetalle.setCantidad(1);
        
        // Usar el método addDetalle de Venta para manejar la bidireccionalidad
        testVenta.addDetalle(initialDetalle); 
        
        // Ahora guarda la venta. Al tener al menos un detalle, pasará la validación.
        testVenta = ventaRepository.save(testVenta);
    }

    @Test
    void testSaveAndFindById() {
        // En esta prueba, puedes crear otro detalle o usar los datos de setUp
        DetalleVenta detalleVenta = new DetalleVenta(); // Nuevo DetalleVenta
        detalleVenta.setProducto(testProducto);
        detalleVenta.setCantidad(3);
        detalleVenta.setVenta(testVenta); // Asociar al testVenta existente

        DetalleVenta savedDetalle = detalleVentaRepository.save(detalleVenta);

        assertNotNull(savedDetalle.getId());
        assertEquals(testProducto.getNombre(), savedDetalle.getProducto().getNombre()); // Comparar por nombre o ID del producto
        assertEquals(3, savedDetalle.getCantidad());
        assertEquals(testVenta.getId(), savedDetalle.getVenta().getId()); // Comparar por ID de la venta

        Optional<DetalleVenta> foundDetalle = detalleVentaRepository.findById(savedDetalle.getId());
        assertTrue(foundDetalle.isPresent());
        assertEquals(savedDetalle.getId(), foundDetalle.get().getId());
        assertEquals(savedDetalle.getCantidad(), foundDetalle.get().getCantidad());
    }

    @Test
    void testFindAll() {
        // En setUp ya se creó un detalle. Crearemos uno más para este test.
        DetalleVenta additionalDetalle = new DetalleVenta();
        additionalDetalle.setProducto(testProducto);
        additionalDetalle.setCantidad(5);
        additionalDetalle.setVenta(testVenta); // Asociar al testVenta
        detalleVentaRepository.save(additionalDetalle);

        List<DetalleVenta> detalles = detalleVentaRepository.findAll();
        assertNotNull(detalles);
        // Ahora esperamos al menos 2 detalles (el de setUp + el de esta prueba)
        assertTrue(detalles.size() >= 2, "Debería haber al menos 2 detalles de venta.");
    }

    @Test
    void testUpdateDetalleVenta() {
        DetalleVenta detalleVenta = new DetalleVenta();
        detalleVenta.setProducto(testProducto);
        detalleVenta.setCantidad(5);
        detalleVenta.setVenta(testVenta); // Asociar al testVenta
        DetalleVenta savedDetalle = detalleVentaRepository.save(detalleVenta);

        savedDetalle.setCantidad(10);
        DetalleVenta updatedDetalle = detalleVentaRepository.save(savedDetalle);

        assertEquals(10, updatedDetalle.getCantidad());
        Optional<DetalleVenta> foundDetalle = detalleVentaRepository.findById(updatedDetalle.getId());
        assertTrue(foundDetalle.isPresent());
        assertEquals(10, foundDetalle.get().getCantidad());
    }

    @Test
    void testDeleteDetalleVenta() {
        DetalleVenta detalleVenta = new DetalleVenta();
        detalleVenta.setProducto(testProducto);
        detalleVenta.setCantidad(4);
        detalleVenta.setVenta(testVenta); // Asociar al testVenta
        DetalleVenta savedDetalle = detalleVentaRepository.save(detalleVenta);

        detalleVentaRepository.deleteById(savedDetalle.getId());
        Optional<DetalleVenta> deletedDetalle = detalleVentaRepository.findById(savedDetalle.getId());
        assertFalse(deletedDetalle.isPresent());
    }
}