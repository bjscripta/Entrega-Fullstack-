package com.venta.venta.service;

import com.venta.venta.model.Inventario;
import com.venta.venta.model.Producto;
import com.venta.venta.repository.InventarioRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

public class InventarioServiceTest {

    @Mock
    private InventarioRepository inventarioRepository;

    @InjectMocks
    private InventarioService inventarioService;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void listar() {
        Inventario inventario1 = new Inventario(1L, new Producto(1L, "Laptop", 1200.00), 10);
        Inventario inventario2 = new Inventario(2L, new Producto(2L, "Mouse", 25.00), 50);
        when(inventarioRepository.findAll()).thenReturn(Arrays.asList(inventario1, inventario2));

        List<Inventario> inventarios = inventarioService.listar();

        assertNotNull(inventarios);
        assertEquals(2, inventarios.size());
        verify(inventarioRepository, times(1)).findAll();
    }

    @Test
    void obtenerPorId() {
        Long inventarioId = 1L;
        Inventario inventario = new Inventario(inventarioId, new Producto(1L, "Laptop", 1200.00), 10);
        when(inventarioRepository.findById(inventarioId)).thenReturn(Optional.of(inventario));

        Optional<Inventario> foundInventario = inventarioService.obtenerPorId(inventarioId);

        assertTrue(foundInventario.isPresent());
        assertEquals(inventarioId, foundInventario.get().getId());
        verify(inventarioRepository, times(1)).findById(inventarioId);
    }

    @Test
    void obtenerPorId_NotFound() {
        Long inventarioId = 1L;
        when(inventarioRepository.findById(inventarioId)).thenReturn(Optional.empty());

        Optional<Inventario> foundInventario = inventarioService.obtenerPorId(inventarioId);

        assertFalse(foundInventario.isPresent());
        verify(inventarioRepository, times(1)).findById(inventarioId);
    }

    @Test
    void guardar() {
        Inventario inventario = new Inventario(null, new Producto(1L, "Laptop", 1200.00), 10);
        when(inventarioRepository.save(inventario)).thenReturn(new Inventario(1L, new Producto(1L, "Laptop", 1200.00), 10));

        Inventario savedInventario = inventarioService.guardar(inventario);

        assertNotNull(savedInventario.getId());
        assertEquals(10, savedInventario.getStock());
        verify(inventarioRepository, times(1)).save(inventario);
    }

    @Test
    void eliminar_Success() {
        Long inventarioId = 1L;
        when(inventarioRepository.existsById(inventarioId)).thenReturn(true);
        doNothing().when(inventarioRepository).deleteById(inventarioId);

        boolean result = inventarioService.eliminar(inventarioId);

        assertTrue(result);
        verify(inventarioRepository, times(1)).existsById(inventarioId);
        verify(inventarioRepository, times(1)).deleteById(inventarioId);
    }

    @Test
    void eliminar_NotFound() {
        Long inventarioId = 1L;
        when(inventarioRepository.existsById(inventarioId)).thenReturn(false);

        boolean result = inventarioService.eliminar(inventarioId);

        assertFalse(result);
        verify(inventarioRepository, times(1)).existsById(inventarioId);
        verify(inventarioRepository, times(0)).deleteById(inventarioId);
    }

    @Test
    void obtenerPorIdProducto() {
        Long productId = 1L;
        Inventario inventario = new Inventario(1L, new Producto(productId, "Laptop", 1200.00), 10);
        when(inventarioRepository.findByProducto_IdProducto(productId)).thenReturn(Optional.of(inventario));

        Optional<Inventario> foundInventario = inventarioService.obtenerPorIdProducto(productId);

        assertTrue(foundInventario.isPresent());
        assertEquals(productId, foundInventario.get().getProducto().getIdProducto());
        verify(inventarioRepository, times(1)).findByProducto_IdProducto(productId);
    }

    @Test
    void obtenerPorIdProducto_NotFound() {
        Long productId = 1L;
        when(inventarioRepository.findByProducto_IdProducto(productId)).thenReturn(Optional.empty());

        Optional<Inventario> foundInventario = inventarioService.obtenerPorIdProducto(productId);

        assertFalse(foundInventario.isPresent());
        verify(inventarioRepository, times(1)).findByProducto_IdProducto(productId);
    }

    @Test
    void actualizar() {
        Inventario inventario = new Inventario(1L, new Producto(1L, "Laptop", 1200.00), 10);
        when(inventarioRepository.save(inventario)).thenReturn(inventario);

        Inventario updatedInventario = inventarioService.actualizar(inventario);

        assertNotNull(updatedInventario);
        assertEquals(10, updatedInventario.getStock());
        verify(inventarioRepository, times(1)).save(inventario);
    }
}