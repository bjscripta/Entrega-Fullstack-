package com.venta.venta.repository;

import com.venta.venta.model.Venta;
import com.venta.venta.model.DetalleVenta; // Importa DetalleVenta
import com.venta.venta.model.Usuario;     // Importa Usuario
import com.venta.venta.model.Producto;    // Importa Producto

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase.Replace;

import java.time.LocalDate;
import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;

@DataJpaTest
@AutoConfigureTestDatabase(replace = Replace.NONE) // Esto es importante si quieres usar una BD real o Docker
public class VentaRepositoryTest {

    @Autowired
    private VentaRepository ventaRepository;
    @Autowired
    private UsuarioRepository usuarioRepository; // Necesitas un usuario para la venta
    @Autowired
    private ProductoRepository productoRepository; // Necesitas un producto para el detalle de venta
    @Autowired
    private DetalleVentaRepository detalleVentaRepository; // Para asegurar que los detalles se guardan si es necesario

    private Usuario testUsuario;
    private Producto testProducto;

    @BeforeEach
    void setUp() {
        // Limpiar la base de datos antes de cada test para asegurar un estado limpio
        detalleVentaRepository.deleteAll();
        ventaRepository.deleteAll();
        usuarioRepository.deleteAll();
        productoRepository.deleteAll();

        // Crear un usuario de prueba
        testUsuario = new Usuario();
        testUsuario.setNombre("UsuarioDePrueba");
        usuarioRepository.save(testUsuario);

        // Crear un producto de prueba
        testProducto = new Producto();
        testProducto.setNombre("ProductoTest");
        testProducto.setPrecio(10.0);
        productoRepository.save(testProducto);
    }

    @Test
    void testSaveVenta() {
        Venta venta = new Venta();
        venta.setDescripcion("Venta de prueba");
        venta.setFechaVenta(LocalDate.now());
        venta.setUsuario(testUsuario);

        // Crear un DetalleVenta y asociarlo a la Venta
        DetalleVenta detalle = new DetalleVenta();
        detalle.setProducto(testProducto);
        detalle.setCantidad(2);
        
        // Usar el método addDetalle de la clase Venta
        venta.addDetalle(detalle); 

        Venta savedVenta = ventaRepository.save(venta);
        assertThat(savedVenta).isNotNull();
        assertThat(savedVenta.getId()).isNotNull();
        assertThat(savedVenta.getDetalles()).isNotEmpty(); // Asegurarse que los detalles fueron guardados
    }

    @Test
    void testFindVentaById() {
        Venta venta = new Venta();
        venta.setDescripcion("Venta a buscar");
        venta.setFechaVenta(LocalDate.now());
        venta.setUsuario(testUsuario);

        DetalleVenta detalle = new DetalleVenta();
        detalle.setProducto(testProducto);
        detalle.setCantidad(1);
        venta.addDetalle(detalle);

        Venta savedVenta = ventaRepository.save(venta);
        Optional<Venta> foundVenta = ventaRepository.findById(savedVenta.getId());
        assertThat(foundVenta).isPresent();
        assertThat(foundVenta.get().getDescripcion()).isEqualTo("Venta a buscar");
    }

    @Test
    void testUpdateVenta() {
        Venta venta = new Venta();
        venta.setDescripcion("Venta inicial");
        venta.setFechaVenta(LocalDate.now());
        venta.setUsuario(testUsuario);
        
        DetalleVenta detalle = new DetalleVenta();
        detalle.setProducto(testProducto);
        detalle.setCantidad(3);
        venta.addDetalle(detalle);

        Venta savedVenta = ventaRepository.save(venta);

        savedVenta.setDescripcion("Venta actualizada");
        Venta updatedVenta = ventaRepository.save(savedVenta);
        assertThat(updatedVenta.getDescripcion()).isEqualTo("Venta actualizada");
    }

    @Test
    void testDeleteVenta() {
        Venta venta = new Venta();
        venta.setDescripcion("Venta a eliminar");
        venta.setFechaVenta(LocalDate.now());
        venta.setUsuario(testUsuario);

        // MODIFICACIÓN CLAVE: Asegurarse de que la venta a eliminar tenga al menos un detalle
        DetalleVenta detalle = new DetalleVenta();
        detalle.setProducto(testProducto);
        detalle.setCantidad(1);
        venta.addDetalle(detalle); // <--- AÑADIDA ESTA LÍNEA (o similar)

        Venta savedVenta = ventaRepository.save(venta);
        Long ventaId = savedVenta.getId();

        ventaRepository.deleteById(ventaId);
        Optional<Venta> deletedVenta = ventaRepository.findById(ventaId);
        assertThat(deletedVenta).isNotPresent();
    }
}