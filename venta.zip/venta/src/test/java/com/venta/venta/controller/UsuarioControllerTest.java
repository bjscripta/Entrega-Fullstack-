package com.venta.venta.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.venta.venta.model.Usuario;
import com.venta.venta.service.UsuarioService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import java.util.Arrays;
import java.util.Optional;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(UsuarioController.class)
public class UsuarioControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private UsuarioService usuarioService;

    @Autowired
    private ObjectMapper objectMapper;

    private Usuario testUsuario;

    @BeforeEach
    void setUp() {
        testUsuario = new Usuario(1L, "Juan Perez");
    }

    @Test
    void listarUsuarios_Success() throws Exception {
        when(usuarioService.listar()).thenReturn(Arrays.asList(testUsuario));

        mockMvc.perform(get("/api/v1/usuarios")
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].id").value(testUsuario.getId()))
                .andExpect(jsonPath("$[0].nombre").value(testUsuario.getNombre()));

        verify(usuarioService, times(1)).listar();
    }

    @Test
    void obtenerUsuarioPorId_Found() throws Exception {
        when(usuarioService.obtenerPorId(testUsuario.getId())).thenReturn(Optional.of(testUsuario));

        mockMvc.perform(get("/api/v1/usuarios/{id}", testUsuario.getId())
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id").value(testUsuario.getId()))
                .andExpect(jsonPath("$.nombre").value(testUsuario.getNombre()));

        verify(usuarioService, times(1)).obtenerPorId(testUsuario.getId());
    }

    @Test
    void obtenerUsuarioPorId_NotFound() throws Exception {
        when(usuarioService.obtenerPorId(testUsuario.getId())).thenReturn(Optional.empty());

        mockMvc.perform(get("/api/v1/usuarios/{id}", testUsuario.getId())
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isNotFound())
                .andExpect(content().string("Usuario no encontrado"));

        verify(usuarioService, times(1)).obtenerPorId(testUsuario.getId());
    }

    @Test
    void crearUsuario_Success() throws Exception {
        Usuario newUsuario = new Usuario(null, "Maria Lopez");
        when(usuarioService.guardar(any(Usuario.class))).thenReturn(new Usuario(2L, "Maria Lopez"));

        mockMvc.perform(post("/api/v1/usuarios")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(newUsuario)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id").exists())
                .andExpect(jsonPath("$.nombre").value("Maria Lopez"));

        verify(usuarioService, times(1)).guardar(any(Usuario.class));
    }

    @Test
    void actualizarUsuario_Success() throws Exception {
        Usuario updatedUsuarioDetails = new Usuario(null, "Juan Carlos Perez");
        Usuario existingUsuario = new Usuario(testUsuario.getId(), "Juan Perez");
        Usuario savedUsuario = new Usuario(testUsuario.getId(), "Juan Carlos Perez");

        when(usuarioService.actualizar(eq(testUsuario.getId()), any(Usuario.class))).thenReturn(savedUsuario);

        mockMvc.perform(put("/api/v1/usuarios/{id}", testUsuario.getId())
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(updatedUsuarioDetails)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id").value(testUsuario.getId()))
                .andExpect(jsonPath("$.nombre").value("Juan Carlos Perez"));

        verify(usuarioService, times(1)).actualizar(eq(testUsuario.getId()), any(Usuario.class));
    }

    @Test
    void actualizarUsuario_NotFound() throws Exception {
        Usuario updatedUsuarioDetails = new Usuario(null, "Juan Carlos Perez");
        when(usuarioService.actualizar(eq(testUsuario.getId()), any(Usuario.class)))
                .thenThrow(new RuntimeException("Usuario no encontrado"));

        mockMvc.perform(put("/api/v1/usuarios/{id}", testUsuario.getId())
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(updatedUsuarioDetails)))
                .andExpect(status().isNotFound())
                .andExpect(content().string("Usuario no encontrado"));

        verify(usuarioService, times(1)).actualizar(eq(testUsuario.getId()), any(Usuario.class));
    }

    @Test
    void eliminarUsuario_Success() throws Exception {
        when(usuarioService.eliminar(testUsuario.getId())).thenReturn(true);

        mockMvc.perform(delete("/api/v1/usuarios/{id}", testUsuario.getId())
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(content().string("Usuario eliminado"));

        verify(usuarioService, times(1)).eliminar(testUsuario.getId());
    }

    @Test
    void eliminarUsuario_NotFound() throws Exception {
        when(usuarioService.eliminar(testUsuario.getId())).thenReturn(false);

        mockMvc.perform(delete("/api/v1/usuarios/{id}", testUsuario.getId())
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isNotFound())
                .andExpect(content().string("Usuario no encontrado"));

        verify(usuarioService, times(1)).eliminar(testUsuario.getId());
    }
}