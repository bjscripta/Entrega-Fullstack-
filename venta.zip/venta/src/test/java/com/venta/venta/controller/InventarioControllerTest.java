package com.venta.venta.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.venta.venta.model.Inventario;
import com.venta.venta.model.Producto;
import com.venta.venta.repository.ProductoRepository;
import com.venta.venta.service.InventarioService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import java.util.Arrays;
import java.util.Optional;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(InventarioController.class)
public class InventarioControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private InventarioService inventarioService;

    @MockBean
    private ProductoRepository productoRepository;

    @Autowired
    private ObjectMapper objectMapper;

    private Producto testProducto;
    private Inventario testInventario;

    @BeforeEach
    void setUp() {
        testProducto = new Producto(1L, "Laptop", 1200.00);
        testInventario = new Inventario(1L, testProducto, 10);
    }

    @Test
    void crearInventario_Success() throws Exception {
        Inventario newInventario = new Inventario(null, testProducto, 15);
        when(productoRepository.findById(testProducto.getIdProducto())).thenReturn(Optional.of(testProducto));
        when(inventarioService.guardar(any(Inventario.class))).thenReturn(new Inventario(2L, testProducto, 15));

        mockMvc.perform(post("/api/v1/inventario")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(newInventario)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id").exists())
                .andExpect(jsonPath("$.stock").value(15));

        verify(productoRepository, times(1)).findById(testProducto.getIdProducto());
        verify(inventarioService, times(1)).guardar(any(Inventario.class));
    }

    @Test
    void crearInventario_ProductIdRequired() throws Exception {
        Inventario newInventario = new Inventario(null, new Producto(), 15); // Producto without ID
        mockMvc.perform(post("/api/v1/inventario")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(newInventario)))
                .andExpect(status().isBadRequest())
                .andExpect(content().string("ID de producto requerido"));

        verify(productoRepository, times(0)).findById(anyLong());
        verify(inventarioService, times(0)).guardar(any(Inventario.class));
    }

    @Test
    void crearInventario_ProductoNotFound() throws Exception {
        Inventario newInventario = new Inventario(null, testProducto, 15);
        when(productoRepository.findById(testProducto.getIdProducto())).thenReturn(Optional.empty());

        mockMvc.perform(post("/api/v1/inventario")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(newInventario)))
                .andExpect(status().isNotFound())
                .andExpect(content().string("Producto no encontrado"));

        verify(productoRepository, times(1)).findById(testProducto.getIdProducto());
        verify(inventarioService, times(0)).guardar(any(Inventario.class));
    }

    @Test
    void crearInventario_InternalError() throws Exception {
        Inventario newInventario = new Inventario(null, testProducto, 15);
        when(productoRepository.findById(testProducto.getIdProducto())).thenReturn(Optional.of(testProducto));
        when(inventarioService.guardar(any(Inventario.class))).thenThrow(new RuntimeException("Database error"));

        mockMvc.perform(post("/api/v1/inventario")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(newInventario)))
                .andExpect(status().isInternalServerError())
                .andExpect(content().string("Error interno: Database error"));

        verify(productoRepository, times(1)).findById(testProducto.getIdProducto());
        verify(inventarioService, times(1)).guardar(any(Inventario.class));
    }


    @Test
    void listarInventario_Success() throws Exception {
        when(inventarioService.listar()).thenReturn(Arrays.asList(testInventario));

        mockMvc.perform(get("/api/v1/inventario")
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].id").value(testInventario.getId()))
                .andExpect(jsonPath("$[0].stock").value(testInventario.getStock()));

        verify(inventarioService, times(1)).listar();
    }

    @Test
    void obtenerPorId_Found() throws Exception {
        when(inventarioService.obtenerPorId(testInventario.getId())).thenReturn(Optional.of(testInventario));

        mockMvc.perform(get("/api/v1/inventario/{id}", testInventario.getId())
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id").value(testInventario.getId()))
                .andExpect(jsonPath("$.stock").value(testInventario.getStock()));

        verify(inventarioService, times(1)).obtenerPorId(testInventario.getId());
    }

    @Test
    void obtenerPorId_NotFound() throws Exception {
        when(inventarioService.obtenerPorId(testInventario.getId())).thenReturn(Optional.empty());

        mockMvc.perform(get("/api/v1/inventario/{id}", testInventario.getId())
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isNotFound())
                .andExpect(content().string("Inventario no encontrado"));

        verify(inventarioService, times(1)).obtenerPorId(testInventario.getId());
    }

    @Test
    void actualizar_Success() throws Exception {
        Inventario updatedInventarioDetails = new Inventario(null, new Producto(2L, "Keyboard", 50.00), 20);
        Inventario existingInventario = new Inventario(testInventario.getId(), testProducto, 10);
        Inventario savedInventario = new Inventario(testInventario.getId(), updatedInventarioDetails.getProducto(), updatedInventarioDetails.getStock());


        when(inventarioService.obtenerPorId(testInventario.getId())).thenReturn(Optional.of(existingInventario));
        when(inventarioService.actualizar(any(Inventario.class))).thenReturn(savedInventario);

        mockMvc.perform(put("/api/v1/inventario/{id}", testInventario.getId())
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(updatedInventarioDetails)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id").value(testInventario.getId()))
                .andExpect(jsonPath("$.stock").value(20));

        verify(inventarioService, times(1)).obtenerPorId(testInventario.getId());
        verify(inventarioService, times(1)).actualizar(any(Inventario.class));
    }

    @Test
    void actualizar_NotFound() throws Exception {
        Inventario updatedInventarioDetails = new Inventario(null, testProducto, 20);
        when(inventarioService.obtenerPorId(testInventario.getId())).thenReturn(Optional.empty());

        mockMvc.perform(put("/api/v1/inventario/{id}", testInventario.getId())
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(updatedInventarioDetails)))
                .andExpect(status().isNotFound())
                .andExpect(content().string("Inventario no encontrado"));

        verify(inventarioService, times(1)).obtenerPorId(testInventario.getId());
        verify(inventarioService, times(0)).actualizar(any(Inventario.class));
    }

    @Test
    void eliminar_Success() throws Exception {
        when(inventarioService.eliminar(testInventario.getId())).thenReturn(true);

        mockMvc.perform(delete("/api/v1/inventario/{id}", testInventario.getId())
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(content().string("Inventario eliminado"));

        verify(inventarioService, times(1)).eliminar(testInventario.getId());
    }

    @Test
    void eliminar_NotFound() throws Exception {
        when(inventarioService.eliminar(testInventario.getId())).thenReturn(false);

        mockMvc.perform(delete("/api/v1/inventario/{id}", testInventario.getId())
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isNotFound())
                .andExpect(content().string("Inventario no encontrado"));

        verify(inventarioService, times(1)).eliminar(testInventario.getId());
    }
}