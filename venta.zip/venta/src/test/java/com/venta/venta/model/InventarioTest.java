package com.venta.venta.model;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class InventarioTest {

    @Test
    void testNoArgsConstructor() {
        Inventario inventario = new Inventario();
        assertNotNull(inventario);
    }

    @Test
    void testAllArgsConstructor() {
        Producto producto = new Producto(1L, "Televisor", 500.00);
        Inventario inventario = new Inventario(1L, producto, 20);
        assertEquals(1L, inventario.getId());
        assertEquals(producto, inventario.getProducto());
        assertEquals(20, inventario.getStock());
    }

    @Test
    void testGettersAndSetters() {
        Inventario inventario = new Inventario();
        Producto producto = new Producto(2L, "Impresora", 250.00);
        inventario.setId(2L);
        inventario.setProducto(producto);
        inventario.setStock(15);

        assertEquals(2L, inventario.getId());
        assertEquals(producto, inventario.getProducto());
        assertEquals(15, inventario.getStock());
    }

    @Test
    void testEqualsAndHashCode() {
        Producto producto1 = new Producto(1L, "Auriculares", 100.00);
        Producto producto2 = new Producto(1L, "Auriculares", 100.00);
        Producto producto3 = new Producto(2L, "Altavoces", 200.00);

        Inventario inventario1 = new Inventario(1L, producto1, 30);
        Inventario inventario2 = new Inventario(1L, producto2, 30);
        Inventario inventario3 = new Inventario(2L, producto3, 5);

        assertEquals(inventario1, inventario2);
        assertNotEquals(inventario1, inventario3);
        assertEquals(inventario1.hashCode(), inventario2.hashCode());
        assertNotEquals(inventario1.hashCode(), inventario3.hashCode());
    }

    @Test
    void testToString() {
        Producto producto = new Producto(1L, "Tablet", 300.00);
        Inventario inventario = new Inventario(1L, producto, 40);
        String expectedToString = "Inventario(id=1, producto=Producto(idProducto=1, nombre=Tablet, precio=300.0), stock=40)";
        assertEquals(expectedToString, inventario.toString());
    }
}