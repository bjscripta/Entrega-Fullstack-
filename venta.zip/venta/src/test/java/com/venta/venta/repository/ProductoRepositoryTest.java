package com.venta.venta.repository;

import com.venta.venta.model.Producto;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase.Replace;

import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;

@DataJpaTest
@AutoConfigureTestDatabase(replace = Replace.NONE) // Use your actual database for testing
class ProductoRepositoryTest {

    @Autowired
    private ProductoRepository productoRepository;

    @Test
    void testSaveAndFindById() {
        Producto producto = new Producto(null, "Laptop", 1200.00);
        Producto savedProducto = productoRepository.save(producto);

        assertNotNull(savedProducto.getIdProducto());
        assertEquals("Laptop", savedProducto.getNombre());
        assertEquals(1200.00, savedProducto.getPrecio());

        Optional<Producto> foundProducto = productoRepository.findById(savedProducto.getIdProducto());
        assertTrue(foundProducto.isPresent());
        assertEquals(savedProducto, foundProducto.get());
    }

    @Test
    void testFindAll() {
        productoRepository.save(new Producto(null, "Mouse", 25.00));
        productoRepository.save(new Producto(null, "Keyboard", 75.00));

        List<Producto> productos = productoRepository.findAll();
        assertNotNull(productos);
        assertTrue(productos.size() >= 2); // May contain existing data
    }

    @Test
    void testUpdateProducto() {
        Producto producto = new Producto(null, "Old Name", 100.00);
        Producto savedProducto = productoRepository.save(producto);

        savedProducto.setNombre("New Name");
        savedProducto.setPrecio(150.00);
        Producto updatedProducto = productoRepository.save(savedProducto);

        assertEquals("New Name", updatedProducto.getNombre());
        assertEquals(150.00, updatedProducto.getPrecio());
        Optional<Producto> foundProducto = productoRepository.findById(updatedProducto.getIdProducto());
        assertTrue(foundProducto.isPresent());
        assertEquals("New Name", foundProducto.get().getNombre());
    }

    @Test
    void testDeleteProducto() {
        Producto producto = new Producto(null, "Product to Delete", 50.00);
        Producto savedProducto = productoRepository.save(producto);

        productoRepository.deleteById(savedProducto.getIdProducto());
        Optional<Producto> deletedProducto = productoRepository.findById(savedProducto.getIdProducto());
        assertFalse(deletedProducto.isPresent());
    }

    @Test
    void testExistsById() {
        Producto producto = new Producto(null, "Product for Exists", 99.99);
        Producto savedProducto = productoRepository.save(producto);

        assertTrue(productoRepository.existsById(savedProducto.getIdProducto()));
        productoRepository.deleteById(savedProducto.getIdProducto());
        assertFalse(productoRepository.existsById(savedProducto.getIdProducto()));
    }
}