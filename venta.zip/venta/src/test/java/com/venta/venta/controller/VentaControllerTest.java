package com.venta.venta.controller;

public class VentaControllerTest {

}
