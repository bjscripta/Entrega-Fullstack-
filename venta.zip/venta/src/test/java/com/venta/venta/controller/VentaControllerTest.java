package com.venta.venta.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.venta.venta.dto.DetalleVentaDTO;
import com.venta.venta.dto.VentaRequest;
import com.venta.venta.model.DetalleVenta;
import com.venta.venta.model.Producto;
import com.venta.venta.model.Usuario;
import com.venta.venta.model.Venta;
import com.venta.venta.repository.ProductoRepository;
import com.venta.venta.repository.UsuarioRepository;
import com.venta.venta.service.VentaService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import java.time.LocalDate;
import java.util.Arrays;
import java.util.Collections;
import java.util.Optional;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyList;
import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(VentaController.class)
public class VentaControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private VentaService ventaService;
    @MockBean
    private UsuarioRepository usuarioRepository;
    @MockBean
    private ProductoRepository productoRepository;

    @Autowired
    private ObjectMapper objectMapper;

    private Usuario testUsuario;
    private Producto testProducto1;
    private Producto testProducto2;
    private DetalleVentaDTO testDetalleDTO1;
    private DetalleVentaDTO testDetalleDTO2;
    private VentaRequest testVentaRequest;
    private Venta testVenta;

    @BeforeEach
    void setUp() {
        testUsuario = new Usuario(1L, "Test User");
        testProducto1 = new Producto(101L, "Product A", 10.0);
        testProducto2 = new Producto(102L, "Product B", 20.0);

        testDetalleDTO1 = new DetalleVentaDTO();
        testDetalleDTO1.setIdProducto(testProducto1.getIdProducto());
        testDetalleDTO1.setCantidad(2);

        testDetalleDTO2 = new DetalleVentaDTO();
        testDetalleDTO2.setIdProducto(testProducto2.getIdProducto());
        testDetalleDTO2.setCantidad(1);

        testVentaRequest = new VentaRequest();
        testVentaRequest.setIdUsuario(testUsuario.getId());
        testVentaRequest.setDescripcion("Test Sale");
        testVentaRequest.setFechaVenta(LocalDate.now());
        testVentaRequest.setDetalles(Arrays.asList(testDetalleDTO1, testDetalleDTO2));

        testVenta = new Venta(1L, "Test Sale", LocalDate.now(), testUsuario, Collections.emptyList());
    }

    @Test
    void registrarVenta_Success() throws Exception {
        when(usuarioRepository.findById(testVentaRequest.getIdUsuario())).thenReturn(Optional.of(testUsuario));
        when(productoRepository.findById(testProducto1.getIdProducto())).thenReturn(Optional.of(testProducto1));
        when(productoRepository.findById(testProducto2.getIdProducto())).thenReturn(Optional.of(testProducto2));
        doNothing().when(ventaService).registrarVenta(any(Venta.class), anyList());

        mockMvc.perform(post("/api/v1/ventas")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(testVentaRequest)))
                .andExpect(status().isOk())
                .andExpect(content().string("Venta registrada con éxito"));

        verify(usuarioRepository, times(1)).findById(testVentaRequest.getIdUsuario());
        verify(productoRepository, times(1)).findById(testProducto1.getIdProducto());
        verify(productoRepository, times(1)).findById(testProducto2.getIdProducto());
        verify(ventaService, times(1)).registrarVenta(any(Venta.class), anyList());
    }

    @Test
    void registrarVenta_UsuarioNotFound() throws Exception {
        when(usuarioRepository.findById(testVentaRequest.getIdUsuario())).thenReturn(Optional.empty());

        mockMvc.perform(post("/api/v1/ventas")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(testVentaRequest)))
                .andExpect(status().isBadRequest())
                .andExpect(content().string("Error: Usuario no encontrado"));

        verify(usuarioRepository, times(1)).findById(testVentaRequest.getIdUsuario());
        verify(productoRepository, times(0)).findById(anyLong());
        verify(ventaService, times(0)).registrarVenta(any(Venta.class), anyList());
    }

    @Test
    void registrarVenta_ProductoNotFound() throws Exception {
        when(usuarioRepository.findById(testVentaRequest.getIdUsuario())).thenReturn(Optional.of(testUsuario));
        when(productoRepository.findById(testProducto1.getIdProducto())).thenReturn(Optional.empty()); // Product 1 not found

        mockMvc.perform(post("/api/v1/ventas")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(testVentaRequest)))
                .andExpect(status().isBadRequest())
                .andExpect(content().string("Error: Producto no encontrado: ID " + testProducto1.getIdProducto()));

        verify(usuarioRepository, times(1)).findById(testVentaRequest.getIdUsuario());
        verify(productoRepository, times(1)).findById(testProducto1.getIdProducto());
        verify(ventaService, times(0)).registrarVenta(any(Venta.class), anyList());
    }

    @Test
    void registrarVenta_ServiceThrowsRuntimeException() throws Exception {
        when(usuarioRepository.findById(testVentaRequest.getIdUsuario())).thenReturn(Optional.of(testUsuario));
        when(productoRepository.findById(testProducto1.getIdProducto())).thenReturn(Optional.of(testProducto1));
        when(productoRepository.findById(testProducto2.getIdProducto())).thenReturn(Optional.of(testProducto2));
        doThrow(new RuntimeException("Stock insuficiente")).when(ventaService).registrarVenta(any(Venta.class), anyList());

        mockMvc.perform(post("/api/v1/ventas")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(testVentaRequest)))
                .andExpect(status().isBadRequest())
                .andExpect(content().string("Error: Stock insuficiente"));

        verify(usuarioRepository, times(1)).findById(testVentaRequest.getIdUsuario());
        verify(productoRepository, times(1)).findById(testProducto1.getIdProducto());
        verify(productoRepository, times(1)).findById(testProducto2.getIdProducto());
        verify(ventaService, times(1)).registrarVenta(any(Venta.class), anyList());
    }

    @Test
    void registrarVenta_ServiceThrowsGenericException() throws Exception {
        when(usuarioRepository.findById(testVentaRequest.getIdUsuario())).thenReturn(Optional.of(testUsuario));
        when(productoRepository.findById(testProducto1.getIdProducto())).thenReturn(Optional.of(testProducto1));
        when(productoRepository.findById(testProducto2.getIdProducto())).thenReturn(Optional.of(testProducto2));
        doThrow(new Exception("Some unexpected error")).when(ventaService).registrarVenta(any(Venta.class), anyList());

        mockMvc.perform(post("/api/v1/ventas")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(testVentaRequest)))
                .andExpect(status().isInternalServerError())
                .andExpect(content().string("Error inesperado: Some unexpected error"));

        verify(usuarioRepository, times(1)).findById(testVentaRequest.getIdUsuario());
        verify(productoRepository, times(1)).findById(testProducto1.getIdProducto());
        verify(productoRepository, times(1)).findById(testProducto2.getIdProducto());
        verify(ventaService, times(1)).registrarVenta(any(Venta.class), anyList());
    }

    @Test
    void listarVentas_Success() throws Exception {
        when(ventaService.listar()).thenReturn(Arrays.asList(testVenta));

        mockMvc.perform(get("/api/v1/ventas")
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].id").value(testVenta.getId()))
                .andExpect(jsonPath("$[0].descripcion").value(testVenta.getDescripcion()));

        verify(ventaService, times(1)).listar();
    }

    @Test
    void obtenerVentaPorId_Found() throws Exception {
        when(ventaService.obtenerPorId(testVenta.getId())).thenReturn(testVenta);

        mockMvc.perform(get("/api/v1/ventas/{id}", testVenta.getId())
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id").value(testVenta.getId()))
                .andExpect(jsonPath("$.descripcion").value(testVenta.getDescripcion()));

        verify(ventaService, times(1)).obtenerPorId(testVenta.getId());
    }

    @Test
    void obtenerVentaPorId_NotFound() throws Exception {
        when(ventaService.obtenerPorId(testVenta.getId())).thenReturn(null);

        mockMvc.perform(get("/api/v1/ventas/{id}", testVenta.getId())
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isNotFound())
                .andExpect(content().string("Venta no encontrada"));

        verify(ventaService, times(1)).obtenerPorId(testVenta.getId());
    }
}