package com.venta.venta.service;

import com.venta.venta.model.Usuario;
import com.venta.venta.repository.UsuarioRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

public class UsuarioServiceTest {

    @Mock
    private UsuarioRepository usuarioRepository;

    @InjectMocks
    private UsuarioService usuarioService;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void listar() {
        Usuario usuario1 = new Usuario(1L, "Alice");
        Usuario usuario2 = new Usuario(2L, "Bob");
        when(usuarioRepository.findAll()).thenReturn(Arrays.asList(usuario1, usuario2));

        List<Usuario> usuarios = usuarioService.listar();

        assertNotNull(usuarios);
        assertEquals(2, usuarios.size());
        verify(usuarioRepository, times(1)).findAll();
    }

    @Test
    void obtenerPorId() {
        Long usuarioId = 1L;
        Usuario usuario = new Usuario(usuarioId, "Alice");
        when(usuarioRepository.findById(usuarioId)).thenReturn(Optional.of(usuario));

        Optional<Usuario> foundUsuario = usuarioService.obtenerPorId(usuarioId);

        assertTrue(foundUsuario.isPresent());
        assertEquals(usuarioId, foundUsuario.get().getId());
        verify(usuarioRepository, times(1)).findById(usuarioId);
    }

    @Test
    void obtenerPorId_NotFound() {
        Long usuarioId = 1L;
        when(usuarioRepository.findById(usuarioId)).thenReturn(Optional.empty());

        Optional<Usuario> foundUsuario = usuarioService.obtenerPorId(usuarioId);

        assertFalse(foundUsuario.isPresent());
        verify(usuarioRepository, times(1)).findById(usuarioId);
    }

    @Test
    void guardar() {
        Usuario usuario = new Usuario(null, "Charlie");
        when(usuarioRepository.save(usuario)).thenReturn(new Usuario(1L, "Charlie"));

        Usuario savedUsuario = usuarioService.guardar(usuario);

        assertNotNull(savedUsuario.getId());
        assertEquals("Charlie", savedUsuario.getNombre());
        verify(usuarioRepository, times(1)).save(usuario);
    }

    @Test
    void actualizar() {
        Long usuarioId = 1L;
        Usuario existingUsuario = new Usuario(usuarioId, "Alice");
        Usuario updatedUsuario = new Usuario(usuarioId, "Alicia");

        when(usuarioRepository.findById(usuarioId)).thenReturn(Optional.of(existingUsuario));
        when(usuarioRepository.save(existingUsuario)).thenReturn(updatedUsuario);

        Usuario result = usuarioService.actualizar(usuarioId, updatedUsuario);

        assertNotNull(result);
        assertEquals("Alicia", result.getNombre());
        verify(usuarioRepository, times(1)).findById(usuarioId);
        verify(usuarioRepository, times(1)).save(existingUsuario);
    }

    @Test
    void actualizar_NotFound() {
        Long usuarioId = 1L;
        Usuario updatedUsuario = new Usuario(usuarioId, "Alicia");
        when(usuarioRepository.findById(usuarioId)).thenReturn(Optional.empty());

        RuntimeException exception = assertThrows(RuntimeException.class, () ->
                usuarioService.actualizar(usuarioId, updatedUsuario));

        assertEquals("Usuario no encontrado", exception.getMessage());
        verify(usuarioRepository, times(1)).findById(usuarioId);
        verify(usuarioRepository, times(0)).save(any(Usuario.class));
    }

    @Test
    void eliminar_Success() {
        Long usuarioId = 1L;
        when(usuarioRepository.existsById(usuarioId)).thenReturn(true);
        doNothing().when(usuarioRepository).deleteById(usuarioId);

        boolean result = usuarioService.eliminar(usuarioId);

        assertTrue(result);
        verify(usuarioRepository, times(1)).existsById(usuarioId);
        verify(usuarioRepository, times(1)).deleteById(usuarioId);
    }

    @Test
    void eliminar_NotFound() {
        Long usuarioId = 1L;
        when(usuarioRepository.existsById(usuarioId)).thenReturn(false);

        boolean result = usuarioService.eliminar(usuarioId);

        assertFalse(result);
        verify(usuarioRepository, times(1)).existsById(usuarioId);
        verify(usuarioRepository, times(0)).deleteById(usuarioId);
    }
}