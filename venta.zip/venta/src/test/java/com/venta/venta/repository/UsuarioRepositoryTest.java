package com.venta.venta.repository;

import com.venta.venta.model.Usuario;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase.Replace;

import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;

@DataJpaTest
@AutoConfigureTestDatabase(replace = Replace.NONE) // Use your actual database for testing
class UsuarioRepositoryTest {

    @Autowired
    private UsuarioRepository usuarioRepository;

    @Test
    void testSaveAndFindById() {
        Usuario usuario = new Usuario("Test User");
        Usuario savedUser = usuarioRepository.save(usuario);

        assertNotNull(savedUser.getId());
        assertEquals("Test User", savedUser.getNombre());

        Optional<Usuario> foundUser = usuarioRepository.findById(savedUser.getId());
        assertTrue(foundUser.isPresent());
        assertEquals(savedUser, foundUser.get());
    }

    @Test
    void testFindAll() {
        usuarioRepository.save(new Usuario("User 1"));
        usuarioRepository.save(new Usuario("User 2"));

        List<Usuario> users = usuarioRepository.findAll();
        assertNotNull(users);
        assertTrue(users.size() >= 2); // May contain existing data if Replace.NONE is used
    }

    @Test
    void testUpdateUser() {
        Usuario usuario = new Usuario("Initial Name");
        Usuario savedUser = usuarioRepository.save(usuario);

        savedUser.setNombre("Updated Name");
        Usuario updatedUser = usuarioRepository.save(savedUser);

        assertEquals("Updated Name", updatedUser.getNombre());
        Optional<Usuario> foundUser = usuarioRepository.findById(updatedUser.getId());
        assertTrue(foundUser.isPresent());
        assertEquals("Updated Name", foundUser.get().getNombre());
    }

    @Test
    void testDeleteUser() {
        Usuario usuario = new Usuario("User to Delete");
        Usuario savedUser = usuarioRepository.save(usuario);

        usuarioRepository.deleteById(savedUser.getId());
        Optional<Usuario> deletedUser = usuarioRepository.findById(savedUser.getId());
        assertFalse(deletedUser.isPresent());
    }

    @Test
    void testExistsById() {
        Usuario usuario = new Usuario("User for Exists");
        Usuario savedUser = usuarioRepository.save(usuario);

        assertTrue(usuarioRepository.existsById(savedUser.getId()));
        usuarioRepository.deleteById(savedUser.getId());
        assertFalse(usuarioRepository.existsById(savedUser.getId()));
    }
}