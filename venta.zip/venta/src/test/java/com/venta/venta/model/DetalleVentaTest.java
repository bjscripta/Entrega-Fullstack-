package com.venta.venta.model;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class DetalleVentaTest {

    @Test
    void testNoArgsConstructor() {
        DetalleVenta detalleVenta = new DetalleVenta();
        assertNotNull(detalleVenta);
    }

    @Test
    void testAllArgsConstructor() {
        Producto producto = new Producto(1L, "Producto X", 100.0);
        Venta venta = new Venta(); // Simplificado para el test de DetalleVenta
        DetalleVenta detalleVenta = new DetalleVenta(1L, producto, 5, venta);
        assertEquals(1L, detalleVenta.getId());
        assertEquals(producto, detalleVenta.getProducto());
        assertEquals(5, detalleVenta.getCantidad());
        assertEquals(venta, detalleVenta.getVenta());
    }

    @Test
    void testGettersAndSetters() {
        DetalleVenta detalleVenta = new DetalleVenta();
        Producto producto = new Producto(2L, "Producto Y", 50.0);
        Venta venta = new Venta();

        detalleVenta.setId(2L);
        detalleVenta.setProducto(producto);
        detalleVenta.setCantidad(3);
        detalleVenta.setVenta(venta);

        assertEquals(2L, detalleVenta.getId());
        assertEquals(producto, detalleVenta.getProducto());
        assertEquals(3, detalleVenta.getCantidad());
        assertEquals(venta, detalleVenta.getVenta());
    }

    @Test
    void testEqualsAndHashCode() {
        Producto producto1 = new Producto(1L, "Prod A", 10.0);
        Producto producto2 = new Producto(1L, "Prod A", 10.0);
        Producto producto3 = new Producto(2L, "Prod B", 20.0);

        Venta venta1 = new Venta();
        Venta venta2 = new Venta();
        Venta venta3 = new Venta();

        DetalleVenta dv1 = new DetalleVenta(1L, producto1, 2, venta1);
        DetalleVenta dv2 = new DetalleVenta(1L, producto2, 2, venta2);
        DetalleVenta dv3 = new DetalleVenta(2L, producto3, 1, venta3);

        assertEquals(dv1, dv2);
        assertNotEquals(dv1, dv3);
        assertEquals(dv1.hashCode(), dv2.hashCode());
        assertNotEquals(dv1.hashCode(), dv3.hashCode());
    }

    @Test
    void testToString() {
        Producto producto = new Producto(1L, "Prod Z", 15.0);
        Venta venta = new Venta();
        DetalleVenta detalleVenta = new DetalleVenta(3L, producto, 7, venta);
        String expectedToString = "DetalleVenta(id=3, producto=Producto(idProducto=1, nombre=Prod Z, precio=15.0), cantidad=7, venta=Venta(id=null, descripcion=null, fechaVenta=null, usuario=null, detalles=[]))";
        assertEquals(expectedToString, detalleVenta.toString());
    }
}