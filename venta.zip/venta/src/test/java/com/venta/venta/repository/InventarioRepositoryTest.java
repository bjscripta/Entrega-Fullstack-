package com.venta.venta.repository;

import com.venta.venta.model.Inventario;
import com.venta.venta.model.Producto;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase.Replace;

import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;

@DataJpaTest
@AutoConfigureTestDatabase(replace = Replace.NONE) // Use your actual database for testing
class InventarioRepositoryTest {

    @Autowired
    private InventarioRepository inventarioRepository;

    @Autowired
    private ProductoRepository productoRepository; // Necesitamos un Producto para Inventario

    private Producto testProducto;

    @BeforeEach
    void setUp() {
        testProducto = productoRepository.save(new Producto(null, "Test Product", 100.00));
    }

    @Test
    void testSaveAndFindById() {
        Inventario inventario = new Inventario(null, testProducto, 50);
        Inventario savedInventario = inventarioRepository.save(inventario);

        assertNotNull(savedInventario.getId());
        assertEquals(testProducto, savedInventario.getProducto());
        assertEquals(50, savedInventario.getStock());

        Optional<Inventario> foundInventario = inventarioRepository.findById(savedInventario.getId());
        assertTrue(foundInventario.isPresent());
        assertEquals(savedInventario, foundInventario.get());
    }

    @Test
    void testFindAll() {
        inventarioRepository.save(new Inventario(null, testProducto, 10));
        inventarioRepository.save(new Inventario(null, testProducto, 20));

        List<Inventario> inventarios = inventarioRepository.findAll();
        assertNotNull(inventarios);
        assertTrue(inventarios.size() >= 2); // May contain existing data
    }

    @Test
    void testUpdateInventario() {
        Inventario inventario = new Inventario(null, testProducto, 30);
        Inventario savedInventario = inventarioRepository.save(inventario);

        savedInventario.setStock(40);
        Inventario updatedInventario = inventarioRepository.save(savedInventario);

        assertEquals(40, updatedInventario.getStock());
        Optional<Inventario> foundInventario = inventarioRepository.findById(updatedInventario.getId());
        assertTrue(foundInventario.isPresent());
        assertEquals(40, foundInventario.get().getStock());
    }

    @Test
    void testDeleteInventario() {
        Inventario inventario = new Inventario(null, testProducto, 25);
        Inventario savedInventario = inventarioRepository.save(inventario);

        inventarioRepository.deleteById(savedInventario.getId());
        Optional<Inventario> deletedInventario = inventarioRepository.findById(savedInventario.getId());
        assertFalse(deletedInventario.isPresent());
    }

    @Test
    void testFindByProducto_IdProducto() {
        Inventario inventario = new Inventario(null, testProducto, 100);
        inventarioRepository.save(inventario);

        Optional<Inventario> foundInventario = inventarioRepository.findByProducto_IdProducto(testProducto.getIdProducto());
        assertTrue(foundInventario.isPresent());
        assertEquals(testProducto.getIdProducto(), foundInventario.get().getProducto().getIdProducto());
        assertEquals(100, foundInventario.get().getStock());
    }

    @Test
    void testFindByProducto_IdProducto_NotFound() {
        Optional<Inventario> foundInventario = inventarioRepository.findByProducto_IdProducto(-1L); // Non-existent product ID
        assertFalse(foundInventario.isPresent());
    }
}