package com.venta.venta.model;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;

import jakarta.persistence.Table;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
@Entity
@Table(name = "Inventario")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Inventario {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne
    @JoinColumn(name = "producto_id")
    @NotNull(message = "El producto no puede ser nulo")
    private Producto producto;

    @Min(value = 0, message = "El stock no puede ser negativo")
    private int stock;

    // Regla de negocio: Podrías añadir un método aquí para verificar el stock antes de una venta
    public boolean tieneSuficienteStock(int cantidadSolicitada) {
        return this.stock >= cantidadSolicitada;
    }
}