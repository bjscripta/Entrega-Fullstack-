package com.venta.venta.controller;


import com.venta.venta.model.Inventario;
import com.venta.venta.model.Producto;
import com.venta.venta.repository.ProductoRepository;
import com.venta.venta.service.InventarioService;
import com.venta.venta.assemblers.InventarioModelAssembler; // Importar el ensamblador

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.hateoas.EntityModel; // Nuevo
import org.springframework.hateoas.CollectionModel; // Nuevo
import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.*; // Nuevo

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors; // Nuevo

@RestController
@RequestMapping("/api/v1/inventario")
@RequiredArgsConstructor
@Tag(name = "INVENTARIO",description = "OPERACION RELACIONADA CON EL STOCK DE LOS PRODUCTOS")
public class InventarioController {

     @Autowired
    private ProductoRepository productoRepository;

    @Autowired
    private InventarioService inventarioService;
    
    @Autowired
    private InventarioModelAssembler assembler; // Inyectar el ensamblador

    @PostMapping
    @Operation(summary = "AGREGAR EL STOCK DE LOS PRODUCTOS",description = "AGREGA UN PRODUCTO AL INVENTARIO Y EL STOCK DE ESTE")
    public ResponseEntity<EntityModel<Inventario>> crearInventario(@RequestBody Inventario inventario) { // Tipo de retorno cambiado
        try {
            if (inventario.getProducto() == null || inventario.getProducto().getIdProducto() == null) {
                return ResponseEntity.badRequest().body(null); // Devolver null en el cuerpo para bad request
            }

            Optional<Producto> productoOpt = productoRepository.findById(inventario.getProducto().getIdProducto());
            if (productoOpt.isEmpty()) {
                return ResponseEntity.status(404).body(null); // Devolver null en el cuerpo para 404
            }

            inventario.setProducto(productoOpt.get());
            Inventario nuevo = inventarioService.guardar(inventario);
            return ResponseEntity.ok(assembler.toModel(nuevo)); // Usar el ensamblador
        } catch (Exception e) {
            return ResponseEntity.status(500).body(null); // Devolver null en el cuerpo para 500
        }
    }
    @GetMapping
    @Operation(summary = "OBTENER EL STOCK DE LOS PRODUCTOS",description = "OBTIENE UNA LISTA DE LOS PRODUCTOS Y SU CANTIDAD ACTUAL")
    public ResponseEntity<CollectionModel<EntityModel<Inventario>>> listarInventario() { // Tipo de retorno cambiado
        List<EntityModel<Inventario>> inventarios = inventarioService.listar().stream()
                .map(assembler::toModel)
                .collect(Collectors.toList());
        return ResponseEntity.ok(CollectionModel.of(inventarios,
                linkTo(methodOn(InventarioController.class).listarInventario()).withSelfRel()));
    }

    @GetMapping("/{id}")
    @Operation(summary = "OBTENER EL STOCK DE LOS PRODUCTOS",description = "OBTIENE UNO DE LOS PRODUCTOS Y SU CANTIDAD ACTUAL SEGUN SU ID")
public ResponseEntity<EntityModel<Inventario>> obtenerPorId(@PathVariable Long id) { // Tipo de retorno cambiado
    Optional<Inventario> inventarioOpt = inventarioService.obtenerPorId(id);

    if (inventarioOpt.isPresent()) {
        return ResponseEntity.ok(assembler.toModel(inventarioOpt.get())); // Usar el ensamblador
    } else {
        return ResponseEntity.status(404).body(null); // Devolver null en el cuerpo para 404
    }
}

    @PutMapping("/{id}")
    @Operation(summary = "ACTUALIZA EL PRODUCTO",description = "MODIFICA EL ID Y/O EL STOCK DE UN PRODUCTO")
    public ResponseEntity<EntityModel<Inventario>> actualizar(@PathVariable Long id, @RequestBody Inventario inventario) { // Tipo de retorno cambiado
        Optional<Inventario> inventarioOpt = inventarioService.obtenerPorId(id);

        if (inventarioOpt.isPresent()) {
            Inventario inv = inventarioOpt.get();
            inv.setProducto(inventario.getProducto());
            inv.setStock(inventario.getStock());
            return ResponseEntity.ok(assembler.toModel(inventarioService.actualizar(inv))); // Usar el ensamblador
        } else {
            return ResponseEntity.status(404).body(null); // Devolver null en el cuerpo para 404
        }
    }

    @DeleteMapping("/{id}")
    @Operation(summary = "ELIMINA PRODUCTO",description = "ELIMINA UN PRODUCTO DEL INVENTARIO SEGUN SU ID")
    public ResponseEntity<?> eliminar(@PathVariable Long id) {
        return inventarioService.eliminar(id)
                ? ResponseEntity.noContent().build() // 204 No Content
                : ResponseEntity.status(404).body("Inventario no encontrado");
    }
}