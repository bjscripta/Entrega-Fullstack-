package com.venta.venta.controller;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.hateoas.EntityModel;
import org.springframework.hateoas.CollectionModel;
import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.*;

import com.venta.venta.assemblers.ProductoModelAssembler;
import com.venta.venta.dto.ProductoRequest;
import com.venta.venta.model.Producto;
import com.venta.venta.service.ProductoService;
// TODO: Verifica que la clase ProductoModelAssembler exista en el paquete correcto.
// Si la clase está en 'com.venta.venta.assembler' (sin 's'), corrige el import así:
// import com.venta.venta.assembler.ProductoModelAssembler;


import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;

@RestController
@RequestMapping("/api/v1/productos")
@RequiredArgsConstructor
@Tag(name = "PRODUCTO",description = "OPERACIONES RELACIONADAS CON LOS PRODUCTOS")
public class ProductoController {

    private final ProductoService productoService;
    private final ProductoModelAssembler assembler; // ¡Aquí debe ser final!

    @PostMapping
    @Operation(summary = "AGREGAR UN PRODUCTO A LA LISTA",description = "AGREGA UN PRODUCTO NUEVO")
    public ResponseEntity<EntityModel<Producto>> agregarProducto(@RequestBody ProductoRequest request) {
        Producto producto = new Producto();
        producto.setNombre(request.getNombre());
        producto.setPrecio(request.getPrecio());
        
        Producto productoGuardado = productoService.guardarProducto(producto);
        return ResponseEntity.ok(assembler.toModel(productoGuardado));
    }

    @GetMapping
    @Operation(summary = "OBTENER LOS PRODUCTOS",description = "OBTIENE UNA LISTA CON TODOS LOS PRODUCTOS EXISTENTES")
    public ResponseEntity<CollectionModel<EntityModel<Producto>>> listarProductos() {
        List<EntityModel<Producto>> productos = productoService.listarProductos().stream()
                .map(assembler::toModel)
                .collect(Collectors.toList());

        return ResponseEntity.ok(CollectionModel.of(productos,
                linkTo(methodOn(ProductoController.class).listarProductos()).withSelfRel()));
    }

    @GetMapping("/{id}")
    @Operation(summary = "OBTENER EL PRODUCTO SEGUN SU ID",description = "OBTIENE UN PRODUCTO ")
    public ResponseEntity<EntityModel<Producto>> obtenerProductoPorId(@PathVariable Long id) {
    return productoService.obtenerPorId(id)
            .map(assembler::toModel)
            .map(ResponseEntity::ok)
            .orElseGet(() -> ResponseEntity.status(404).body(null));
}

    @PutMapping("/{id}")
    @Operation(summary = "ACTUALIZA PRODUCTO",description = "MODIFICA UN PRODUCTO POR SU ID")
    public ResponseEntity<EntityModel<Producto>> actualizarProducto(@PathVariable Long id, @RequestBody ProductoRequest request) {
        Producto productoActualizado = new Producto();
        productoActualizado.setNombre(request.getNombre());
        productoActualizado.setPrecio(request.getPrecio());

        try {
            Producto producto = productoService.actualizarProducto(id, productoActualizado);
            return ResponseEntity.ok(assembler.toModel(producto));
        } catch (RuntimeException e) {
            return ResponseEntity.status(404).body(null);
        }
    }

    @DeleteMapping("/{id}")
    @Operation(summary = "ELIMINAR PRODUCTO",description = "ELIMINA PRODUCTO SEGUN SU ID")
    public ResponseEntity<?> eliminarProducto(@PathVariable Long id) {
        try {
            productoService.eliminarProducto(id);
            return ResponseEntity.noContent().build();
        } catch (Exception e) {
            return ResponseEntity.status(404).body("Producto no encontrado");
        }
    }
}