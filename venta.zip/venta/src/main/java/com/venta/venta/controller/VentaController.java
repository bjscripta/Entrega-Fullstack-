package com.venta.venta.controller;

import com.venta.venta.dto.DetalleVentaDTO;
import com.venta.venta.dto.VentaRequest;
import com.venta.venta.model.DetalleVenta;
import com.venta.venta.model.Producto;
import com.venta.venta.model.Usuario;
import com.venta.venta.model.Venta;
import com.venta.venta.repository.ProductoRepository;
import com.venta.venta.repository.UsuarioRepository;
import com.venta.venta.service.VentaService;
import com.venta.venta.assemblers.VentaModelAssembler; // Importar el ensamblador
import com.venta.venta.assemblers.DetalleVentaModelAssembler; // Importar el ensamblador de DetalleVenta si se usa directamente

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.hateoas.EntityModel; // Nuevo
import org.springframework.hateoas.CollectionModel; // Nuevo
import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.*; // Nuevo

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors; // Nuevo

@RestController
@RequestMapping("/api/v1/ventas")
@RequiredArgsConstructor
@Tag(name = "VENTAS",description = "OPERACIONES RELACIONADAS A LAS VENTAS")
public class VentaController {

    private final VentaService ventaService;
    private final UsuarioRepository usuarioRepository;
    private final ProductoRepository productoRepository;
    private final VentaModelAssembler ventaAssembler; // Inyectar el ensamblador de Venta
    private final DetalleVentaModelAssembler detalleVentaAssembler; // Inyectar si se va a usar para los detalles incrustados

    @PostMapping
    @Operation(summary = "CREAR VENTA",description = "CREA UNA NUEVA VENTA DE UN USUARIO")
    public ResponseEntity<EntityModel<Venta>> registrarVenta(@RequestBody VentaRequest request) { // Tipo de retorno cambiado
        try {
            Usuario usuario = usuarioRepository.findById(request.getIdUsuario())
                    .orElseThrow(() -> new RuntimeException("Usuario no encontrado"));

            Venta venta = new Venta();
            venta.setUsuario(usuario);
            venta.setDescripcion(request.getDescripcion());
            venta.setFechaVenta(request.getFechaVenta());

            List<DetalleVenta> detalles = new ArrayList<>();
            for (DetalleVentaDTO dto : request.getDetalles()) {
                Producto producto = productoRepository.findById(dto.getIdProducto())
                        .orElseThrow(() -> new RuntimeException("Producto no encontrado: ID " + dto.getIdProducto()));

                DetalleVenta detalle = new DetalleVenta();
                detalle.setProducto(producto);
                detalle.setCantidad(dto.getCantidad());
                detalle.setVenta(venta);
                detalles.add(detalle);
            }

            ventaService.registrarVenta(venta, detalles); // registrarVenta actualiza el stock y guarda los detalles.

            // Retornar la venta con HATEOAS. Es importante que el servicio haya guardado la venta y sus detalles para que tengan IDs.
            // Para esto, necesitarías que registrarVenta devuelva la Venta completa con sus detalles persistidos.
            // Asumiendo que el `venta` objeto aquí ya tiene su ID después de `ventaRepository.save` en el servicio:
            return ResponseEntity.ok(ventaAssembler.toModel(venta)); // Usar el ensamblador para la venta creada

        } catch (RuntimeException e) {
            return ResponseEntity.badRequest().body(null); // Devolver null en el cuerpo para bad request
        } catch (Exception e) {
            return ResponseEntity.internalServerError().body(null); // Devolver null en el cuerpo para 500
        }
    }

    @GetMapping
    @Operation(summary = "OBTENER TODAS LAS VENTAS",description = "OBTIENE UNA LISTA DE LAS VENTAS")
    public ResponseEntity<CollectionModel<EntityModel<Venta>>> listarVentas() { // Tipo de retorno cambiado
        List<EntityModel<Venta>> ventas = ventaService.listar().stream()
                .map(ventaAssembler::toModel)
                .collect(Collectors.toList());
        return ResponseEntity.ok(CollectionModel.of(ventas,
                linkTo(methodOn(VentaController.class).listarVentas()).withSelfRel()));
    }

    @GetMapping("/{id}")
    @Operation(summary = "OBTENER UNA VENTA",description = "OBTIENE UN DETALLE VENTA SEGUN SU ID")
    public ResponseEntity<EntityModel<Venta>> obtenerVentaPorId(@PathVariable Long id) { // Tipo de retorno cambiado
        Venta venta = ventaService.obtenerPorId(id);
        if (venta == null) {
            return ResponseEntity.status(404).body(null); // Devolver null en el cuerpo para 404
        }
        return ResponseEntity.ok(ventaAssembler.toModel(venta)); // Usar el ensamblador
    }
}