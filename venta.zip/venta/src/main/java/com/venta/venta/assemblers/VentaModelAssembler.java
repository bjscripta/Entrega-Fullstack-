package com.venta.venta.assemblers;

import com.venta.venta.controller.VentaController;
import com.venta.venta.model.Venta;
import org.springframework.hateoas.EntityModel;
import org.springframework.hateoas.server.RepresentationModelAssembler;
import org.springframework.stereotype.Component;

import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.linkTo;
import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.methodOn;

@Component
public class VentaModelAssembler implements RepresentationModelAssembler<Venta, EntityModel<Venta>> {

    @Override
    public EntityModel<Venta> toModel(Venta venta) {
        EntityModel<Venta> ventaModel = EntityModel.of(venta,
                linkTo(methodOn(VentaController.class).obtenerVentaPorId(venta.getId())).withSelfRel(),
                linkTo(methodOn(VentaController.class).listarVentas()).withRel("ventas"));

        // Si quieres incluir enlaces a los detalles de venta, podrías hacerlo aquí
        // venta.getDetalles().forEach(detalle -> ventaModel.add(
        //         linkTo(methodOn(DetalleVentaController.class).obtenerDetalleVentaPorId(detalle.getId())).withRel("detalle-venta")
        // ));

        return ventaModel;
    }
}