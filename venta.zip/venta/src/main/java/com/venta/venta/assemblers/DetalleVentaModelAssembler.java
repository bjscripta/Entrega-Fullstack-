package com.venta.venta.assemblers;

import com.venta.venta.controller.VentaController; // Para enlazar a la venta principal
import com.venta.venta.model.DetalleVenta;
import org.springframework.hateoas.EntityModel;
import org.springframework.hateoas.server.RepresentationModelAssembler;
import org.springframework.stereotype.Component;

import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.linkTo;
import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.methodOn;

@Component
public class DetalleVentaModelAssembler implements RepresentationModelAssembler<DetalleVenta, EntityModel<DetalleVenta>> {

    @Override
    public EntityModel<DetalleVenta> toModel(DetalleVenta detalleVenta) {
        EntityModel<DetalleVenta> detalleModel = EntityModel.of(detalleVenta);

        // Enlace a la venta principal si existe
        if (detalleVenta.getVenta() != null && detalleVenta.getVenta().getId() != null) {
            detalleModel.add(linkTo(methodOn(VentaController.class).obtenerVentaPorId(detalleVenta.getVenta().getId())).withRel("venta"));
        }
        
        // Si tuvieras un DetalleVentaController para operaciones individuales (CRUD para DetalleVenta),
        // descomenta la siguiente línea para añadir un enlace "self" al detalle específico.
        // Actualmente, tu estructura sugiere que DetalleVenta se maneja más como parte de Venta.
        // detalleModel.add(linkTo(methodOn(DetalleVentaController.class).obtenerDetalleVentaPorId(detalleVenta.getId())).withSelfRel());
        
        return detalleModel;
    }
}