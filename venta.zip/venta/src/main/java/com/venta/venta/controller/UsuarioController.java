package com.venta.venta.controller;

import com.venta.venta.model.Usuario;
import com.venta.venta.service.UsuarioService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/usuarios")
@RequiredArgsConstructor
@Tag(name = "USUARIOS",description = "OPERACIONES RELACIONADAS A LOS USUARIOS")
public class UsuarioController {

    private final UsuarioService usuarioService;

    @GetMapping
    @Operation(summary = "OBTENER TODOS LOS USUARIOS",description = "OBTIENE UNA LISTA DE LOS USUARIOS")
    public List<Usuario> listarUsuarios() {
        return usuarioService.listar();
    }

    @GetMapping("/{id}")
    @Operation(summary = "OBTENER USUARIOS",description = "OBTIENE UN USUARIOS SEGUN SU ID")
        public ResponseEntity<?> obtenerUsuarioPorId(@PathVariable Long id) {
        var usuario = usuarioService.obtenerPorId(id);
     if (usuario.isPresent()) {
        return ResponseEntity.ok(usuario.get());
    } else {
        return ResponseEntity.status(404).body("Usuario no encontrado");
    }
}

    @PostMapping
    @Operation(summary = "CREA DATOS DE USUARIO PARA GENERAR COMPRA",description = "AÑADE LOS DATOS DE LOS USUARIOS PARA PODER GENERAR UNA COMPRA")
    public ResponseEntity<Usuario> crearUsuario(@RequestBody Usuario usuario) {
        return ResponseEntity.ok(usuarioService.guardar(usuario));
    }

    @PutMapping("/{id}")
    @Operation(summary = "ACTUALIZAR USUARIO",description = "MODIFICA EL NOMBRE Y/O ID DEL USUARIO")
    public ResponseEntity<?> actualizarUsuario(@PathVariable Long id, @RequestBody Usuario usuario) {
        try {
            Usuario actualizado = usuarioService.actualizar(id, usuario);
            return ResponseEntity.ok(actualizado);
        } catch (RuntimeException e) {
            return ResponseEntity.status(404).body(e.getMessage());
        }
    }

    @DeleteMapping("/{id}")
    @Operation(summary = "ELIMINAR USUARIO",description = "ELIMINAR USUARIO SEGUN SU ID")
    public ResponseEntity<?> eliminarUsuario(@PathVariable Long id) {
        if (usuarioService.eliminar(id)) {
            return ResponseEntity.ok("Usuario eliminado");
        } else {
            return ResponseEntity.status(404).body("Usuario no encontrado");
        }
    }
}