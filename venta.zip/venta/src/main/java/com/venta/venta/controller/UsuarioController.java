package com.venta.venta.controller;

import com.venta.venta.model.Usuario;
import com.venta.venta.service.UsuarioService;
import com.venta.venta.assemblers.UsuarioModelAssembler; // Importar el ensamblador

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.hateoas.EntityModel; // Nuevo
import org.springframework.hateoas.CollectionModel; // Nuevo
import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.*; // Nuevo

import java.util.List;
import java.util.stream.Collectors; // Nuevo

@RestController
@RequestMapping("/api/v1/usuarios")
@RequiredArgsConstructor
@Tag(name = "USUARIOS",description = "OPERACIONES RELACIONADAS A LOS USUARIOS")
public class UsuarioController {

    private final UsuarioService usuarioService;
    private final UsuarioModelAssembler assembler; // Inyectar el ensamblador

    @GetMapping
    @Operation(summary = "OBTENER TODOS LOS USUARIOS",description = "OBTIENE UNA LISTA DE LOS USUARIOS")
    public ResponseEntity<CollectionModel<EntityModel<Usuario>>> listarUsuarios() { // Tipo de retorno cambiado
        List<EntityModel<Usuario>> usuarios = usuarioService.listar().stream()
                .map(assembler::toModel)
                .collect(Collectors.toList());
        return ResponseEntity.ok(CollectionModel.of(usuarios,
                linkTo(methodOn(UsuarioController.class).listarUsuarios()).withSelfRel()));
    }

    @GetMapping("/{id}")
    @Operation(summary = "OBTENER USUARIOS",description = "OBTIENE UN USUARIOS SEGUN SU ID")
    public ResponseEntity<EntityModel<Usuario>> obtenerUsuarioPorId(@PathVariable Long id) { // Tipo de retorno cambiado
        return usuarioService.obtenerPorId(id)
                .map(assembler::toModel)
                .map(ResponseEntity::ok)
                .orElseGet(() -> ResponseEntity.status(404).body(null)); // Devolver null en el cuerpo para 404
    }

    @PostMapping
    @Operation(summary = "CREA DATOS DE USUARIO PARA GENERAR COMPRA",description = "AÑADE LOS DATOS DE LOS USUARIOS PARA PODER GENERAR UNA COMPRA")
    public ResponseEntity<EntityModel<Usuario>> crearUsuario(@RequestBody Usuario usuario) { // Tipo de retorno cambiado
        Usuario savedUsuario = usuarioService.guardar(usuario);
        return ResponseEntity.ok(assembler.toModel(savedUsuario)); // Usar el ensamblador
    }

    @PutMapping("/{id}")
    @Operation(summary = "ACTUALIZAR USUARIO",description = "MODIFICA EL NOMBRE Y/O ID DEL USUARIO")
    public ResponseEntity<EntityModel<Usuario>> actualizarUsuario(@PathVariable Long id, @RequestBody Usuario usuario) { // Tipo de retorno cambiado
        try {
            Usuario actualizado = usuarioService.actualizar(id, usuario);
            return ResponseEntity.ok(assembler.toModel(actualizado)); // Usar el ensamblador
        } catch (RuntimeException e) {
            return ResponseEntity.status(404).body(null); // Devolver null en el cuerpo para 404
        }
    }

    @DeleteMapping("/{id}")
    @Operation(summary = "ELIMINAR USUARIO",description = "ELIMINAR USUARIO SEGUN SU ID")
    public ResponseEntity<?> eliminarUsuario(@PathVariable Long id) {
        if (usuarioService.eliminar(id)) {
            return ResponseEntity.noContent().build(); // 204 No Content
        } else {
            return ResponseEntity.status(404).body("Usuario no encontrado");
        }
    }
}