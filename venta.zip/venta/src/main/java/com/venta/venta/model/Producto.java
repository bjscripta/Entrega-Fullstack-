package com.venta.venta.model;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
@Entity
@Table(name = "Producto")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Producto {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long idProducto;

    @NotBlank(message = "El nombre del producto no puede estar en blanco")
    @Size(min = 3, max = 255, message = "El nombre del producto debe tener entre 3 y 255 caracteres")
    @Column(unique = true) // Regla de negocio: el nombre del producto debe ser único
    private String nombre;

    @DecimalMin(value = "0.01", message = "El precio debe ser mayor que 0")
    private double precio;
}