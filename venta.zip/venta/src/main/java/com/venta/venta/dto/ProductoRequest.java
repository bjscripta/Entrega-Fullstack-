package com.venta.venta.dto;

import lombok.Data;

@Data
public class ProductoRequest {
    private String nombre;
    private double precio;
}
