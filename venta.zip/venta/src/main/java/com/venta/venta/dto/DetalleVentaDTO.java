package com.venta.venta.dto;

import lombok.Data;

@Data
public class DetalleVentaDTO {
    private Long idProducto;
    private int cantidad;
}
