package com.venta.venta.model;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.PastOrPresent;
import jakarta.validation.constraints.Size;
import jakarta.validation.constraints.NotEmpty; // <-- Añadido: Importa esta anotación

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
@Entity
@Table(name = "Venta")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Venta {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Size(max = 500, message = "La descripción no puede exceder los 500 caracteres")
    private String descripcion;

    @NotNull(message = "La fecha de venta no puede ser nula")
    @PastOrPresent(message = "La fecha de venta no puede ser futura")
    private LocalDate fechaVenta;

    @ManyToOne
    @NotNull(message = "El usuario no puede ser nulo")
    private Usuario usuario;

    @OneToMany(mappedBy = "venta", cascade = CascadeType.ALL, orphanRemoval = true)
    @NotEmpty(message = "La venta debe tener al menos un detalle") // <-- Añadido: Validación para que la lista no esté vacía
    private List<DetalleVenta> detalles = new ArrayList<>();

    // Métodos para manejar la relación bidireccional (recomendados con Lombok @Data)
    public void addDetalle(DetalleVenta detalle) {
        if (detalles == null) {
            detalles = new ArrayList<>();
        }
        detalles.add(detalle);
        detalle.setVenta(this);
    }

    public void removeDetalle(DetalleVenta detalle) {
        if (detalles != null) {
            detalles.remove(detalle);
            detalle.setVenta(null);
        }
    }
}