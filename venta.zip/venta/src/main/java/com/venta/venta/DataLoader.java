package com.venta.venta;

import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Component;
import org.springframework.beans.factory.annotation.Autowired;

import com.venta.venta.model.DetalleVenta;
import com.venta.venta.model.Inventario;
import com.venta.venta.model.Producto;
import com.venta.venta.model.Usuario;
import com.venta.venta.model.Venta;
import com.venta.venta.repository.InventarioRepository;
import com.venta.venta.repository.ProductoRepository;
import com.venta.venta.repository.UsuarioRepository;
import com.venta.venta.repository.VentaRepository;
import com.venta.venta.repository.DetalleVentaRepository; // Aunque no lo usaremos para guardar directamente, lo mantengo por si acaso

import net.datafaker.Faker;

import java.time.LocalDate;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.concurrent.TimeUnit;

@Profile("dev")
@Component
public class DataLoader implements CommandLineRunner{
    @Autowired
    private UsuarioRepository usuarioRepository;
    @Autowired
    private DetalleVentaRepository detalleVentaRepository; // Ya no lo necesitas para guardar DetalleVenta directamente
    @Autowired
    private VentaRepository ventaRepository;
    @Autowired
    private ProductoRepository productoRepository;
    @Autowired
    private InventarioRepository inventarioRepository;

    @Override
    public void run(String... args) throws Exception {
        Faker faker = new Faker();
        Random random = new Random();

        // Limpiar la base de datos para evitar duplicados en cada ejecución
        // Esto es opcional, pero útil para desarrollo con DataLoader
        detalleVentaRepository.deleteAll();
        ventaRepository.deleteAll();
        inventarioRepository.deleteAll();
        productoRepository.deleteAll();
        usuarioRepository.deleteAll();


        // Create 10 Usuarios
        List<Usuario> usuarios = new ArrayList<>();
        for (int i = 0; i < 10; i++) {
            Usuario usuario = new Usuario(faker.name().fullName());
            usuarios.add(usuarioRepository.save(usuario));
        }

        // Create 10 Productos
        List<Producto> productos = new ArrayList<>();
        for (int i = 0; i < 10; i++) {
            Producto producto = new Producto();
            producto.setNombre(faker.commerce().productName());
            producto.setPrecio(faker.number().randomDouble(2, 5, 1000));
            productos.add(productoRepository.save(producto));
        }

        // Create 10 Inventarios (sin cambios relevantes aquí para el error actual)
        List<Inventario> inventarios = new ArrayList<>();
        for (int i = 0; i < 10; i++) {
            Inventario inventario = new Inventario();
            inventario.setProducto(productos.get(random.nextInt(productos.size())));
            inventario.setStock(faker.number().numberBetween(10, 500));
            inventarios.add(inventarioRepository.save(inventario));
        }

        // MODIFICACIÓN CLAVE: Crear las Ventas y sus DetalleVentas juntos
        List<Venta> ventas = new ArrayList<>();
        for (int i = 0; i < 10; i++) {
            Venta venta = new Venta();
            venta.setDescripcion(faker.lorem().sentence());
            venta.setFechaVenta(faker.date().past(365, TimeUnit.DAYS).toInstant().atZone(ZoneId.systemDefault()).toLocalDate());
            venta.setUsuario(usuarios.get(random.nextInt(usuarios.size())));

            // Crear AL MENOS UN DetalleVenta y añadirlo a la venta ANTES de guardarla
            int numberOfDetails = random.nextInt(3) + 1; // Generar entre 1 y 3 detalles por venta
            for (int j = 0; j < numberOfDetails; j++) {
                DetalleVenta detalleVenta = new DetalleVenta();
                detalleVenta.setProducto(productos.get(random.nextInt(productos.size())));
                detalleVenta.setCantidad(faker.number().numberBetween(1, 10));
                
                // Usar el método addDetalle de la Venta para establecer la relación bidireccional
                venta.addDetalle(detalleVenta); 
            }
            
            // Ahora guarda la venta. Como ya le hemos añadido detalles, pasará la validación @NotEmpty.
            ventas.add(ventaRepository.save(venta)); 
        }

        // El bucle para crear DetalleVentas por separado ya no es necesario aquí
        // porque se crean y asocian con la Venta antes de guardar la Venta.
        // Si tienes lógica para crear DetalleVentas no asociadas a una Venta
        // (lo cual es inusual para un DetalleVenta), lo mantendrías, pero no para este caso.
        /*
        for (int i = 0; i < 10; i++) {
            DetalleVenta detalleVenta = new DetalleVenta();
            detalleVenta.setProducto(productos.get(random.nextInt(productos.size())));
            detalleVenta.setCantidad(faker.number().numberBetween(1, 10));
            detalleVenta.setVenta(ventas.get(random.nextInt(ventas.size())));
            detalleVentaRepository.save(detalleVenta);
        }
        */

        System.out.println("Database seeded with data for Usuarios, Productos, Inventarios, y Ventas con sus DetalleVentas.");
    }
}