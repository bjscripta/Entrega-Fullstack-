package com.venta.venta;

import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Component;
import org.springframework.beans.factory.annotation.Autowired;

import com.venta.venta.model.DetalleVenta;
import com.venta.venta.model.Inventario;
import com.venta.venta.model.Producto;
import com.venta.venta.model.Usuario;
import com.venta.venta.model.Venta;
import com.venta.venta.repository.InventarioRepository;
import com.venta.venta.repository.ProductoRepository;
import com.venta.venta.repository.UsuarioRepository;
import com.venta.venta.repository.VentaRepository;
import com.venta.venta.repository.DetalleVentaRepository;

import net.datafaker.Faker;

import java.time.LocalDate;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.concurrent.TimeUnit;

@Profile("dev")
@Component
public class DataLoader implements CommandLineRunner{
    @Autowired
    private UsuarioRepository usuarioRepository;
    @Autowired
    private DetalleVentaRepository detalleVentaRepository;
    @Autowired
    private VentaRepository ventaRepository;
    @Autowired
    private ProductoRepository productoRepository;
    @Autowired
    private InventarioRepository inventarioRepository;

    @Override
    public void run(String... args) throws Exception {
        Faker faker = new Faker();
        Random random = new Random();

        // Create 10 Usuarios
        List<Usuario> usuarios = new ArrayList<>();
        for (int i = 0; i < 10; i++) {
            Usuario usuario = new Usuario(faker.name().fullName());
            usuarios.add(usuarioRepository.save(usuario));
        }

        // Create 10 Productos
        List<Producto> productos = new ArrayList<>();
        for (int i = 0; i < 10; i++) {
            Producto producto = new Producto();
            producto.setNombre(faker.commerce().productName());
            producto.setPrecio(faker.number().randomDouble(2, 5, 1000));
            productos.add(productoRepository.save(producto));
        }

        // Create 10 Inventarios
        List<Inventario> inventarios = new ArrayList<>();
        for (int i = 0; i < 10; i++) {
            Inventario inventario = new Inventario();
            inventario.setProducto(productos.get(random.nextInt(productos.size())));
            inventario.setStock(faker.number().numberBetween(10, 500));
            inventarios.add(inventarioRepository.save(inventario));
        }

        // Create 10 Ventas
        List<Venta> ventas = new ArrayList<>();
        for (int i = 0; i < 10; i++) {
            Venta venta = new Venta();
            venta.setDescripcion(faker.lorem().sentence());
            venta.setFechaVenta(faker.date().past(365, TimeUnit.DAYS).toInstant().atZone(ZoneId.systemDefault()).toLocalDate());
            venta.setUsuario(usuarios.get(random.nextInt(usuarios.size())));
            ventas.add(ventaRepository.save(venta));
        }

        // Create 10 DetalleVentas
        for (int i = 0; i < 10; i++) {
            DetalleVenta detalleVenta = new DetalleVenta();
            detalleVenta.setProducto(productos.get(random.nextInt(productos.size())));
            detalleVenta.setCantidad(faker.number().numberBetween(1, 10));
            detalleVenta.setVenta(ventas.get(random.nextInt(ventas.size())));
            detalleVentaRepository.save(detalleVenta);
        }

        System.out.println("Database seeded with 10 entries for each entity.");
    }
}